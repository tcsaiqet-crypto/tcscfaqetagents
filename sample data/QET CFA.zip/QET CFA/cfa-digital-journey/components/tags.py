import streamlit as st

def render_system_badge(text: str = "System Verified ✓", help_text: str = "Deterministic rule / database fact. Trust fully."):
    st.markdown(
        f'<span title="{help_text}" style="background:#E8F5E9;color:#1B5E20;padding:3px 10px;border-radius:12px;font-size:0.8rem;font-weight:600;">{text}</span>',
        unsafe_allow_html=True
    )

def render_ai_badge(text: str = "AI Suggested ✨", help_text: str = "AI-generated recommendation. Advisory only."):
    st.markdown(
        f'<span title="{help_text}" style="background:#F3E5F5;color:#6A1B9A;padding:3px 10px;border-radius:12px;font-size:0.8rem;font-weight:600;">{text}</span>',
        unsafe_allow_html=True
    )

def render_hybrid_badge(text: str = "AI + System ◈", help_text: str = "Hybrid: rule decided, AI explained."):
    st.markdown(
        f'<span title="{help_text}" style="background:#E3F2FD;color:#0D47A1;padding:3px 10px;border-radius:12px;font-size:0.8rem;font-weight:600;">{text}</span>',
        unsafe_allow_html=True
    )

def render_curriculum_badge(text: str = "Curriculum ✓", help_text: str = "Fixed official CFA curriculum content."):
    st.markdown(
        f'<span title="{help_text}" style="background:#F5F5F5;color:#616161;padding:3px 10px;border-radius:12px;font-size:0.8rem;font-weight:600;">{text}</span>',
        unsafe_allow_html=True
    )

def render_disclaimer(text: str = "AI suggestion — advisory only. Verify against official CFA materials."):
    st.markdown(
        f'<p style="font-size:0.75rem;color:#757575;font-style:italic;margin-top:0.25rem;">{text}</p>',
        unsafe_allow_html=True
    )
