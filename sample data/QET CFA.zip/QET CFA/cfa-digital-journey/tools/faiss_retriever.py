import os
import json
from typing import List, Dict, Any, Optional

REFUSAL_PHRASE = "I don't have that information. Please refer to the official CFA Institute website (cfainstitute.org)."

AGENT_PERMISSIONS = {
    "router": [],
    "tutor": ["curriculum_l1", "curriculum_l2", "curriculum_l3", "glossary"],
    "planner": ["curriculum_l1", "curriculum_l2", "curriculum_l3", "question_bank"],
    "support": ["faq_support", "policies_fees", "glossary"]
}

class FAISSIndexRetriever:
    def __init__(self, base_dir: Optional[str] = None):
        self.base_dir = base_dir or os.getenv("VECTOR_STORE_DIR", os.path.join("vector_store", "faiss_indexes"))
        
    def retrieve(
        self,
        query: str,
        agent_role: str = "tutor",
        domain: str = "curriculum_l1",
        top_k: int = 4
    ) -> Dict[str, Any]:
        """
        Retrieves context chunks from domain-isolated FAISS indexes.
        Enforces agent permission allow-list and returns grounded refusal if index is missing/empty.
        """
        agent_role = agent_role.lower()
        allowed = AGENT_PERMISSIONS.get(agent_role, [])
        
        if domain not in allowed:
            return {
                "chunks": [],
                "sources": [],
                "text": REFUSAL_PHRASE,
                "reason": f"Agent '{agent_role}' is not authorized to query domain '{domain}'."
            }
            
        index_path = os.path.join(self.base_dir, domain)
        if not os.path.exists(index_path):
            return {
                "chunks": [],
                "sources": [],
                "text": REFUSAL_PHRASE,
                "reason": f"Index domain '{domain}' not found on disk."
            }
            
        # Guard top_k to avoid excessive noisy context.
        top_k = max(1, min(int(top_k or 4), 10))

        # Mock / LangChain FAISS retrieval fallback logic
        meta_file = os.path.join(index_path, "index_meta.json")
        if os.path.exists(meta_file):
            try:
                with open(meta_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    chunks = data.get("chunks", [])

                    # Deduplicate repeated chunk payloads from metadata build artifacts.
                    deduped_chunks = []
                    seen_keys = set()
                    for c in chunks:
                        key = (
                            (c.get("chunk_id") or "").strip(),
                            (c.get("source") or "").strip(),
                            (c.get("content") or "").strip().lower(),
                        )
                        if key in seen_keys:
                            continue
                        seen_keys.add(key)
                        deduped_chunks.append(c)

                    # Simple keyword similarity score simulation
                    scored = []
                    q_words = [w.lower().strip(".,:;!?()[]{}\"'") for w in query.split() if w.strip()]
                    for idx, c in enumerate(deduped_chunks):
                        content = c.get("content", "")
                        if not content:
                            continue
                        content_lower = content.lower()
                        match_count = 0
                        for w in q_words:
                            # check exact word or stem match (first 4 chars)
                            if w in content_lower or (len(w) >= 4 and w[:4] in content_lower):
                                match_count += 1
                        if match_count > 0:
                            # Sort by match score desc, then shorter chunks first, then stable index.
                            scored.append((match_count, -len(content_lower), -idx, c))
                    scored.sort(reverse=True)
                    top_matches = [item[3] for item in scored[:top_k]]
                    
                    if not top_matches:
                        return {
                            "chunks": [],
                            "sources": [],
                            "text": REFUSAL_PHRASE
                        }
                        
                    return {
                        "chunks": [m["content"] for m in top_matches],
                        "sources": [m.get("source", domain) for m in top_matches],
                        "text": "\n---\n".join([m["content"] for m in top_matches])
                    }
            except Exception:
                pass
                
        return {
            "chunks": [],
            "sources": [],
            "text": REFUSAL_PHRASE
        }
