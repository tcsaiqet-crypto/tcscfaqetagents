from typing import Dict, Any, Optional
from services.support_service import create_support_ticket

def support_ticket_tool(
    candidate_id: int,
    subject: str,
    description: str,
    priority: str = "normal",
    page_context: str = "Help & Support"
) -> Dict[str, Any]:
    """
    Tool function for Support Agent to create tickets.
    """
    return create_support_ticket(
        candidate_id=candidate_id,
        subject=subject,
        description=description,
        priority=priority,
        page_context=page_context
    )
