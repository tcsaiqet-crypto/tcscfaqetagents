# CFA Digital Candidate Journey Platform

End-to-End Digital Candidate Journey Platform covering the full candidate lifecycle for the CFA Examination & Learning Ecosystem (BR-01 through BR-18).

## Architecture & Governance

Built according to Speckit methodology and governed by the canonical project constitution located in `.specify/memory/constitution.md`.

### Core Architectural Principles:
1. **Deterministic Business Logic First**: All eligibility, payment, scoring, KYC, scheduling, and business decisions are implemented as pure Python rules engines.
2. **AI Narrates, Never Decides**: CrewAI multi-agent companion system explains, advises, and tutors candidates, but cannot modify core business state.
3. **Domain-Isolated Vector Stores**: FAISS split indexes per domain (`curriculum_l1`, `curriculum_l2`, `curriculum_l3`, `policies_fees`, `faq_support`, `glossary`, `question_bank`).
4. **LLM Provider Switcher**: Runtime toggle between OpenAI (GPT-4o) and Google Gemini while fixing embeddings to `text-embedding-3-small`.
5. **Accessibility, Privacy & Reliability**: WCAG 2.1 AA compliant UI, PII encryption at rest, comprehensive audit logging in SQLite, and retry/fault-tolerance.

## Setup & Running

1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Run the application:
   ```bash
   streamlit run app.py
   ```
