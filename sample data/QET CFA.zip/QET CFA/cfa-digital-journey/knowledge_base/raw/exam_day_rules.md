# CFA Exam Day Rules and Proctoring Guidelines

*Source Note: Synthetic document summarizing exam day requirements, CBT interface rules, and proctoring parameters.*

---

## 1. COMPUTER-BASED TESTING (CBT) OVERVIEW

CFA Exams are delivered globally as Computer-Based Tests (CBT) through Prometric test centers, or via remote online proctoring where eligible.
- **Check-in Process**: Candidates must arrive 30 minutes before their scheduled slot. Identity re-verification is required.
- **Liveness Verification**: Biometric check-in is performed at test centers.

---

## 2. EXAM DAY RULES & PROHIBITED ITEMS

- **Approved Identification**: A valid, international passport is required.
  - *Coverage Gap Note: The exact list of acceptable alternative national/regional IDs for candidates in specific jurisdictions is NOT detailed in local sources. Check cfainstitute.org for localized exceptions.*
- **Calculator Policy**: Candidates are permitted to bring only approved calculator models into the testing room.
  - Approved Calculator Models:
    - Texas Instruments BA II Plus (including BA II Plus Professional)
    - Hewlett Packard 12C (including HP 12c Platinum, 12c Platinum 25th Anniversary Edition, 12c 30th Anniversary Edition, and HP 12c Prestige)
  - *Coverage Gap Note: No other calculator manufacturers or models are approved. The exact model suffix acceptance details are subject to change. Refer to cfainstitute.org for updates.*
- **Personal Belongings**: All bags, cellular phones, smartwatches, papers, and writing instruments (other than provided scrap boards) are strictly prohibited in the testing room.

---

## 3. PROCTORING INTEGRITY AND REAL-TIME SIGNAL LOGGING

For remote or center-based AI-assisted proctoring sessions:
- **Liveness & Face Detection**: The system continuously monitors the candidate's video feed.
  - **Threshold**: If the candidate's face is not detected for more than **5 consecutive seconds**, an integrity flag is generated.
- **Audio Verification**: Ambient sound and secondary voice detection rules apply.
  - **Threshold**: Detection of secondary speech triggers an integrity flag.
- **Audit Logging**: All integrity events (flags, timestamps, reason codes) are saved in the `exam_sessions` database and routed to the administrator integrity log.

---

## 4. TESTING ACCOMMODATIONS

Candidates with documented medical conditions or disabilities may request testing accommodations (such as extra exam time, screen readers, or specialized hardware).
- **Request Timeline**: Accommodations must be requested and approved before scheduling the exam slot.
- *Coverage Gap Note: The complete list of approved accommodations and required medical documentation formats is NOT fully detailed in current sources. Refer to the accommodations tile on cfainstitute.org to apply.*
