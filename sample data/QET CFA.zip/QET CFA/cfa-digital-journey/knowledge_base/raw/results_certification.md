# CFA Exam Results & Charterholder Certification Guidelines

*Source Note: Synthetic policy document detailing the result publication timeline, score breakdown structure, and charterholder requirements.*

---

## 1. RESULTS TIMELINE AND RELEASE

- **Release Window**:
  - Level I and Level II exam results are typically published within **8 weeks** of the close of the testing window.
  - Level III exam results are published within **10 weeks** of the close of the testing window.
- **Delivery**: Candidates receive results via email notification followed by access to the digital candidate portal.
- **SLA Commitment**: Results release is dependent on completing the mandatory Practical Skills Modules (PSM) for that level.

---

## 2. SCORE REPORTS AND MPS

- **Minimum Passing Score (MPS)**: The MPS is established by the CFA Institute Board of Governors for each exam window.
- **Performance Breakdown**:
  - Score reports do not show a raw percentage score.
  - Results show a Pass/Fail status alongside confidence bands indicating performance relative to the MPS.
  - Topic-level performance is presented in bands (e.g., above, at, or below 70%).

---

## 3. CFA CHARTERHOLDER REQUIREMENTS

To earn the CFA Charter and use the CFA designation, successful candidates must meet the following criteria:
1. **Pass all three levels**: Complete and pass Level I, Level II, and Level III examinations sequentially.
2. **Work Experience**: Accrue a minimum of **4,000 hours** of acceptable professional work experience completed over a minimum of **36 months**.
3. **Professional References**: Provide 2 or 3 professional references to vouch for professional character and experience.
4. **Membership**: Apply for regular membership in the CFA Institute and pay annual dues of **USD 299**.
5. **Annual Attestation**: Complete the annual Professional Conduct Statement and regular attestation.

---

## 4. DIGITAL CREDENTIALING & SHARING

- **Verifiable Digital Badges**: Issued automatically upon charter approval via a secure, tamper-proof credential service.
- **Sharing**: Badge includes a public verification link suitable for sharing on LinkedIn, resumes, and professional networks.
- **Third-Party Validation**: Third parties can instantly verify status and validity of credentials using the verification ID code.
