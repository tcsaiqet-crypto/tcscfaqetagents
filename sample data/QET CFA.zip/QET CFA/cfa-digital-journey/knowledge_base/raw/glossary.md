# CFA Candidate Program Glossary

*Source Note: Synthetic glossary containing core terms and definitions for the candidate journey.*

---

- **CFA Charter**: The professional credential awarded by the CFA Institute to finance professionals who pass all three exam levels and meet work experience requirements.
- **CFA Charterholder**: A regular member of the CFA Institute who has successfully earned the CFA Charter.
- **Candidate**: A registered participant in the CFA Program.
- **Levels I, II, and III**: The three sequential exam levels of the CFA Program.
- **Learning Ecosystem (LES)**: The official digital study platform provided to candidates.
- **Prometric**: The Computer-Based Testing (CBT) partner delivering the exams.
- **Practical Skills Module (PSM)**: Mandatory, ungraded hands-on learning modules (Python, Financial Modeling, etc.) required for result release.
- **Enrollment Fee**: One-time fee for first-time candidates (eliminated for 2026 windows onwards).
- **Registration Fee**: Fee paid per exam level registration (Early or Standard rates apply).
- **Early Registration Window**: Initial registration period offering discounted pricing.
- **Standard Registration Window**: General registration period at standard pricing.
- **Deferral**: Postponement of an exam window registration to a future window, subject to rules.
- **Exam Window**: The multi-day testing block during which CBT slots are scheduled.
- **Computer-Based Testing (CBT)**: The digital format of the exams.
- **Testing Accommodation**: Approved modifications to exam timing, settings, or equipment for candidates with disabilities.
- **Score Report**: Official document indicating pass/fail status and performance breakdown.
- **Work Experience Requirement**: The 4,000 hours of professional finance experience over >=36 months required for certification.
- **Professional Reference**: References required to sponsor a candidate's membership application.
- **Annual Dues**: Regular membership fee (USD 299).
- **GIPS®**: Global Investment Performance Standards (ethics curriculum component).
- **Code of Ethics**: The core ethical tenets governing CFA candidates and charterholders.
- **Standards of Professional Conduct**: Seven specific standards governing professional behavior.
- **LOS (Learning Outcome Statement)**: Direct statements detailing what candidates should know or be able to do.
- **MPS (Minimum Passing Score)**: The threshold passing mark established for each exam window.
- **CBOK (Candidate Body of Knowledge)**: The complete framework of topics tested.
- **Study Session**: Organizing unit grouping curriculum readings.
- **Topic Area Weights**: The target percentage allocation of exam questions per topic.
- **Digital Badge**: Secure credential issued to show successful completion of levels or charter.
- **Specialized Pathways**: Selectable Level III tracks starting in 2025 (Portfolio Management, Private Wealth, Private Markets).
