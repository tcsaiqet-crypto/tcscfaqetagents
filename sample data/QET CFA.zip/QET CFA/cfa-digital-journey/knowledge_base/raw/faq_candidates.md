# CFA Candidate Frequently Asked Questions (FAQ)

*Source Note: Synthetic candidate FAQ list covering registration, study, exam day, results, and technical queries.*

---

## 1. REGISTRATION AND SCHEDULING

### Q: How do I register for the CFA exam?
A: Registration is a two-step process. First, register and pay fees on the CFA Institute website. Second, schedule your specific exam date and location slot through Prometric.

### Q: Can I sign in using Social Login or Single Sign-On (SSO)?
A: Yes. The candidate portal supports SSO integrations for Google, LinkedIn, and corporate partner logins, allowing single-click access.

---

## 2. FEES AND REFUNDS

### Q: What is the refund policy?
A: Candidates are eligible for a full refund of registration fees within 14 days of transaction completion. After 14 days, fees are non-refundable.

---

## 3. STUDY AND CURRICULUM

### Q: How many hours should I study?
A: The recommended benchmark is at least **300 hours** of preparation per level.

### Q: What is the Learning Ecosystem (LES)?
A: The LES is the digital platform providing curriculum content, reading materials, videos, flashcards, practice questions, and mock tests.

### Q: What should I target on mock exams?
A: Candidates should target a score of **70% or higher** on mock exams to demonstrate exam readiness.

---

## 4. PRACTICAL SKILLS MODULES (PSM)

### Q: Are PSMs graded?
A: No. PSMs are not graded. They are mandatory modules consisting of videos and practical cases to ensure relevant hands-on skills. You must complete them to have your results released.

---

## 5. EXAM DAY AND PROCTORING

### Q: Can I use a calculator?
A: Only the approved Texas Instruments BA II Plus and HP 12C models are allowed in the testing room.

---

## 6. RESULTS AND CERTIFICATION

### Q: When will I get my score report?
A: Level I/II results are released within 8 weeks, and Level III results within 10 weeks of the testing window.

### Q: Who do I contact for support?
A: For scheduling issues, contact Prometric. For curriculum, registration, or invoice issues, contact CFA Institute candidate support.
