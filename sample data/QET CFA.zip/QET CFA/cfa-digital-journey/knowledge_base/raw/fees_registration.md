# CFA Program Fees & Registration Policy Reference Guide

*Source Note: Synthetic policy document outlining the 2025 and 2026 fee schedules, eligibility rules, and exam window allocations.*

---

## 1. EXAM FEES AND PRICING SCHEDULE

All fees are in USD (United States Dollars). Applicable taxes are calculated and added at checkout.

### 2025 Fee Schedule
- **One-time Enrollment Fee**: USD 350 (required for first-time Level I registration).
- **Early Registration Fee**: USD 940 (by level, for early registration windows).
- **Standard Registration Fee**: USD 1,250 (by level, for standard registration windows).

### 2026 Fee Schedule (Effective April 29, 2025 for February 2026 onwards)
- **One-time Enrollment Fee**: USD 0 (The enrollment fee is eliminated effective 29 April 2025 for all candidates registering for February 2026 and later exam windows).
- **Early Registration Fee**: USD 1,090
- **Standard Registration Fee**: USD 1,390

*Note: All registration deadlines are strictly enforced at 11:59 PM Eastern Time (ET) on the respective deadline date.*

---

## 2. EXAM WINDOW MATRIX

| Level | Exam Windows Per Year | Timing / Months |
|---|---|---|
| Level I | 4 times per year | February, May, August, November |
| Level II | 3 times per year | May, August, November |
| Level III | 2 times per year | February, August |

---

## 3. ELIGIBILITY REQUIREMENTS

To register for the CFA Program and enroll in the Level I exam, a candidate must satisfy one of the following eligibility pathways:
1. **Bachelor's Degree**: Complete a bachelor's degree or equivalent program.
2. **Final-Year Student**: Be within 23 months of graduation for a bachelor's degree or equivalent.
3. **Professional Work Experience**: Have a combination of professional work experience and/or higher education that totals at least 4,000 hours accrued over a minimum of 36 sequential months.

### Identification Requirement
- Candidates must possess a valid, international, machine-readable passport to register and sit for the exam.

---

## 4. ATTEMPT LIMITS & RETAKE POLICY

- **Lifetime Limit**: Candidates are limited to a maximum of 6 exam attempts per level.
- **Retake Gap**: Exam attempts must be scheduled at least 6 months apart.
- **No Consecutive Windows**: Candidates cannot sit for exams in consecutive testing windows for the same level.

---

## 5. RESCHEDULING & DEFERRALS

- **Rescheduling Fee**: Candidates may reschedule their exam appointment within their active testing window for a fee of **USD 250**.
- **Deferral Policy**: Deferrals are granted under strict emergency guidelines or as paid deferrals.
- **Pass Rate Warning**: Candidates who defer their exam show statistically lower pass rates in subsequent attempts (~29% for deferred vs ~50% for first-time takers).

---

## 6. INVOICE AND PAYMENT DEADLINES

- Invoice payment methods (bank transfers) must be cleared and confirmed within 10 business days of invoice generation or prior to the registration deadline (whichever is earlier).
