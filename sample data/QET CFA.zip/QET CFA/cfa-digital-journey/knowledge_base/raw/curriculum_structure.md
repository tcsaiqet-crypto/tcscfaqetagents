# CFA Program Curriculum Structure & Reference Guide

*Source Note: Extracted from official CFA Program materials. Level I detailed; Level II and Level III weights/pathways only.*

---

## 1. LEVEL I CURRICULUM STRUCTURE

### Topic Areas & Exam Weights
The Level I curriculum focuses on building a solid foundation in finance, ethics, and analysis.

| Topic Area | Weight % | Brief Description |
|---|---|---|
| Ethical and Professional Standards | 15-20% | Code of Ethics, Standards of Professional Conduct, GIPS® |
| Quantitative Methods | 6-9% | Time Value of Money, descriptive statistics, probability theory, risk quantification |
| Economics | 6-9% | Supply/demand, market structures, macro principles, FX, regulation |
| Financial Statement Analysis | 11-14% | Reporting procedures, statements, alternative accounting, analysis framework |
| Corporate Issuers | 6-9% | Governance, investing/financing, stakeholders, ESG, leverage, working capital |
| Equity Investments | 11-14% | Equity characteristics, markets, indexes, industry/company analysis, valuation |
| Fixed Income | 11-14% | Fixed income securities, yields, risk, valuation, securitization, credit |
| Derivatives | 5-8% | Forwards, futures, swaps, contingent claims, arbitrage |
| Alternative Investments | 7-10% | Hedge funds, PE, real estate, commodities, infrastructure |
| Portfolio Management | 8-12% | Portfolio/risk fundamentals, return/risk, planning, CAPM |

### Study Sessions
The curriculum is organized into Study Sessions as listed below:

| Study Session | Name / Topic Area | Topics Covered |
|---|---|---|
| SS 1 | Ethical and Professional Standards | Ethical framework, Code & Standards, GIPS® |
| SS 2 | Quantitative Methods: Basic Concepts | TVM, probability, descriptive statistics |
| SS 3 | Quantitative Methods: Application | Probability distributions, technical analysis |
| SS 7 | FRA: Introduction | Reporting principles, statements, disclosures, audit |
| SS 8 | FRA: Statements | Income Statement, Balance Sheet, Cash Flow, ratios/techniques |
| SS 9 | FRA: Assets & Liabilities | Inventories, long-lived assets, taxes, long-term liabilities |
| SS 10 | Financial Reporting Quality and Applications | Quality, cash flow manipulation, screening |
| SS 11 | Corporate Finance | Capital budgeting, WACC, leverage, dividends, working capital, governance |
| SS 12 | Portfolio Management | Portfolio approach, MPT, IPS |
| SS 13 | Equity: Market Organization and Structure | Markets, intermediaries, indices, efficiency |
| SS 14 | Equity Analysis and Valuation | Equity features, industry/company analysis, valuation tools |
| SS 15 | Fixed Income: Basic Concepts | Debt features, risks, sectors, yields |
| SS 16 | Fixed Income: Analysis and Valuation | Valuation, spots/forwards, IR risk, credit |
| SS 17 | Derivatives | Forwards, futures, swaps, options |
| SS 18 | Alternative Investments | Alts characteristics, commodities, HF fees, PE, Real Estate |

*Coverage Gap Note: Study Sessions 4, 5, and 6 (which traditionally cover Economics) are omitted from direct session lists. Economics content is covered under newer Learning Module formats.*

### Readings & Learning Modules
Below is the representative reading list:

- **Reading 1**: Code of Ethics and Standards of Professional Conduct (SS 1)
- **Reading 2**: Guidance for Standards I–VII (SS 1)
- **Reading 3**: Introduction to GIPS® (SS 1)
- **Reading 4**: Global Investment Performance Standards (GIPS®) (SS 1)
- **Reading 5**: The Time Value of Money (SS 2)
- **Reading 7**: Statistical Concepts and Market Returns (SS 2)
- **Reading 8**: Probability Concepts (SS 2)
- **Reading 9**: Common Probability Distributions (SS 3)
- **Reading 12**: Technical Analysis (SS 3)
- **Reading 22**: Financial Statement Analysis: An Introduction (SS 7)
- **Reading 23**: Financial Reporting Mechanics (SS 7)
- **Reading 24**: Financial Reporting Standards (SS 7)
- **Reading 25**: Understanding Income Statements (SS 8)
- **Reading 26**: Understanding Balance Sheets (SS 8)
- **Reading 27**: Understanding Cash Flow Statements (SS 8)
- **Reading 28**: Financial Analysis Techniques (SS 8)
- **Readings 29–32**: Inventories; Long-lived Assets; Income Taxes; Non-current Liabilities (SS 9)
- **Readings 33–35**: Reporting Quality; Cash Flow Shenanigans; FSA Applications (SS 10)
- **Readings 36–41**: Capital Budgeting; Cost of Capital; Leverage; Dividends; Working Capital; Governance (SS 11)
- **Readings 43–45**: Portfolio Risk/Return I–II; Portfolio Planning (SS 12)
- **Readings 46–48**: Market Organization; Indices; Market Efficiency (SS 13)
- **Readings 49–51**: Equity Securities; Industry/Company Analysis; Equity Valuation (SS 14)
- **Readings 52–55**: Debt Features; Bond Risks; Bond Sectors; Yield Spreads (SS 15)
- **Readings 56–59**: Debt Valuation; Yields/Spots/Forwards; IR Risk; Credit Analysis (SS 16)
- **Readings 60–64**: Derivative Markets; Forwards; Futures; Options; Swaps (SS 17)
- **Readings 66–67**: Introduction to Alternative Investments; Investing in Commodities (SS 18)

---

## 2. LEVEL II CURRICULUM WEIGHTS

*Coverage Gap Note: Detailed readings and LOS lists are incomplete. Below are the exam topic weights.*

| Topic Area | Weight % |
|---|---|
| Ethical and Professional Standards | 10-15% |
| Quantitative Methods | 5-10% |
| Economics | 5-10% |
| Financial Statement Analysis | 10-15% |
| Corporate Issuers | 5-10% |
| Equity Investments | 10-15% |
| Fixed Income | 10-15% |
| Derivatives | 5-10% |
| Alternative Investments | 5-10% |
| Portfolio Management & Wealth Planning | 10-15% |

---

## 3. LEVEL III CURRICULUM WEIGHTS & PATHWAYS

*Coverage Gap Note: Detailed readings and LOS lists are incomplete. Below are the exam topic weights.*

- **Common Core Topics**: ~67% (two-thirds) of exam weight.
- **Specialized Pathway Topics**: ~33% (one-third) of exam weight.

| Component | Weight % |
|---|---|
| Asset Allocation | 15-20% |
| Portfolio Construction | 15-20% |
| Performance Measurement | 5-10% |
| Derivatives and Risk Management | 10-15% |
| Ethical and Professional Standards | 10-15% |
| Specialized Pathways | 30-35% |

### Specialized Pathways (Effective February 2025 Exam Windows)
Candidates must select one of the following three specialized pathways. All three pathways lead to the same CFA Charter.
1. **Portfolio Management**
2. **Private Wealth**
3. **Private Markets**

---

## 4. PREREQUISITES & PRACTICAL SKILLS MODULES (PSM)

### Exam Prerequisites
- Sequential progression: Candidates must pass Level I before sitting for Level II, and pass Level II before sitting for Level III.
- A minimum study commitment benchmark of **300 hours** per level is recommended.

### Practical Skills Modules (PSM)
- Mandatory requirement: Candidates must complete at least one PSM per level to release their official exam results.
- PSMs are ungraded but include low-stakes verification quizzes. They require approximately 10-20 hours of study time.
- Same module cannot be reused across levels.
- **Level I Options**: Financial Modeling OR Python Programming Fundamentals.
- **Level II Options**: Analyst Skills OR Python, Data Science & AI.
- **Level III Options**: Mandatory requirement for February 2025 and later testing windows.
