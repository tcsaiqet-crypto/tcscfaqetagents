import streamlit as st
from services.profile_service import get_candidate_by_id
from agents.crew_config import AgentManager
from components.tags import render_disclaimer

st.set_page_config(page_title="AI Companion Full Chat", layout="wide", page_icon="💬")

if "active_candidate_id" not in st.session_state:
    st.error("No active candidate selected. Return to main app first.")
    if st.button("Back to App"):
        st.switch_page("app.py")
    st.stop()

if "companion_messages" not in st.session_state:
    st.session_state["companion_messages"] = []
if "llm_provider" not in st.session_state:
    st.session_state["llm_provider"] = "openai"
if "response_preset" not in st.session_state:
    st.session_state["response_preset"] = "balanced"
if "custom_instruction_text" not in st.session_state:
    st.session_state["custom_instruction_text"] = ""
if "custom_instruction_enabled" not in st.session_state:
    st.session_state["custom_instruction_enabled"] = False
if "context_depth" not in st.session_state:
    st.session_state["context_depth"] = 4
if "agent_override" not in st.session_state:
    st.session_state["agent_override"] = "auto"
if "domain_override" not in st.session_state:
    st.session_state["domain_override"] = "auto"

current_cand = get_candidate_by_id(st.session_state["active_candidate_id"])
active_context = st.session_state.get("active_context", "General")

header_col1, header_col2 = st.columns([5, 1])
with header_col1:
    st.title("AI Companion - Full Chat")
    st.caption(f"Context: {active_context} | Provider: {st.session_state['llm_provider'].upper()}")
with header_col2:
    if st.button("Back to App", use_container_width=True):
        st.switch_page("app.py")

st.markdown("Recommended default: Balanced. You can add a custom instruction and turn it ON/OFF.")

ctrl_col1, ctrl_col2, ctrl_col3 = st.columns([2, 2, 2])
with ctrl_col1:
    st.session_state["response_preset"] = st.selectbox(
        "Response style",
        ["auto", "balanced", "concise", "detailed", "examples"],
        index=["auto", "balanced", "concise", "detailed", "examples"].index(
            st.session_state["response_preset"] if st.session_state["response_preset"] in ["auto", "balanced", "concise", "detailed", "examples"] else "balanced"
        ),
        key="fullchat_response_preset",
    )
with ctrl_col2:
    st.session_state["custom_instruction_enabled"] = st.toggle(
        "Apply Custom Instruction",
        value=st.session_state["custom_instruction_enabled"],
        key="fullchat_custom_toggle",
    )
with ctrl_col3:
    if st.button("Clear Chat", use_container_width=True):
        st.session_state["companion_messages"] = []
        st.rerun()

st.session_state["custom_instruction_text"] = st.text_input(
    "Custom instruction",
    value=st.session_state["custom_instruction_text"],
    placeholder="Example: answer in table + 3 examples + medium length",
    max_chars=200,
    key="fullchat_custom_instruction",
)

with st.expander("Advanced options", expanded=False):
    adv_col1, adv_col2 = st.columns(2)
    with adv_col1:
        st.session_state["agent_override"] = st.selectbox(
            "Agent override",
            ["auto", "tutor", "planner", "support"],
            index=["auto", "tutor", "planner", "support"].index(
                st.session_state["agent_override"] if st.session_state["agent_override"] in ["auto", "tutor", "planner", "support"] else "auto"
            ),
            key="fullchat_agent_override",
        )
    with adv_col2:
        st.session_state["domain_override"] = st.selectbox(
            "Domain override",
            ["auto", "curriculum_l1", "curriculum_l2", "curriculum_l3", "faq_support", "policies_fees", "glossary", "question_bank"],
            index=["auto", "curriculum_l1", "curriculum_l2", "curriculum_l3", "faq_support", "policies_fees", "glossary", "question_bank"].index(
                st.session_state["domain_override"] if st.session_state["domain_override"] in ["auto", "curriculum_l1", "curriculum_l2", "curriculum_l3", "faq_support", "policies_fees", "glossary", "question_bank"] else "auto"
            ),
            key="fullchat_domain_override",
        )
    st.session_state["context_depth"] = st.slider(
        "Context depth (chunks)",
        1,
        10,
        int(st.session_state["context_depth"]),
        key="fullchat_context_depth",
    )

with st.container(height=640):
    if not st.session_state["companion_messages"]:
        st.info("Ask questions about curriculum, profile types, study planning, or support policies.")

    for msg in st.session_state["companion_messages"]:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])
            if msg["role"] == "assistant" and msg.get("meta"):
                meta = msg["meta"]
                st.caption(
                    f"preset={meta.get('preset','-')} | agent={meta.get('agent','-')} | domain={meta.get('domain','-')} | k={meta.get('context_depth','-')}"
                )
            if msg.get("sources"):
                with st.expander("View Sources"):
                    for src in msg["sources"]:
                        st.caption(f"Source: {src}")

with st.form("full_chat_composer", clear_on_submit=True):
    user_text = st.text_input("Ask AI Companion", placeholder="Type your question...", label_visibility="collapsed")
    send = st.form_submit_button("Send", use_container_width=True)

    if send and user_text.strip():
        st.session_state["companion_messages"].append({
            "role": "user",
            "content": user_text.strip(),
        })

        custom_instruction = st.session_state["custom_instruction_text"].strip() if st.session_state["custom_instruction_enabled"] else ""
        response_options = {
            "preset": st.session_state["response_preset"],
            "custom_instruction": custom_instruction,
            "context_depth": st.session_state["context_depth"],
            "agent_override": None if st.session_state["agent_override"] == "auto" else st.session_state["agent_override"],
            "domain_override": None if st.session_state["domain_override"] == "auto" else st.session_state["domain_override"],
        }

        mgr = AgentManager()
        resp = mgr.process_query(
            user_text.strip(),
            active_context,
            current_cand,
            st.session_state["llm_provider"],
            response_options=response_options,
        )

        st.session_state["companion_messages"].append({
            "role": "assistant",
            "content": resp["response"],
            "sources": resp.get("sources", []),
            "meta": {
                "preset": resp.get("preset_used", st.session_state["response_preset"]),
                "agent": resp.get("agent_used"),
                "domain": resp.get("domain_queried"),
                "context_depth": st.session_state["context_depth"],
            },
        })

        if len(st.session_state["companion_messages"]) > 100:
            st.session_state["companion_messages"] = st.session_state["companion_messages"][-100:]

        st.rerun()

render_disclaimer()
