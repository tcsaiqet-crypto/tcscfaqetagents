import os
from typing import Optional, Any

def get_chat_model(provider: Optional[str] = None) -> Any:
    """
    Factory pattern for switching between OpenAI and Gemini chat models.
    Default provider is loaded from environment variable or session state.
    """
    prov = (provider or os.getenv("DEFAULT_LLM_PROVIDER", "openai")).lower()
    
    if prov == "openai":
        from langchain_openai import ChatOpenAI
        api_key = os.getenv("OPENAI_API_KEY")
        return ChatOpenAI(model="gpt-4o", openai_api_key=api_key)
    elif prov == "gemini":
        from langchain_google_genai import ChatGoogleGenerativeAI
        api_key = os.getenv("GEMINI_API_KEY")
        return ChatGoogleGenerativeAI(model="gemini-2.0-flash", google_api_key=api_key)
    else:
        raise ValueError(f"Unsupported LLM provider: {prov}")

def get_frozen_embedding_model() -> Any:
    """
    Returns the fixed embedding model OpenAI text-embedding-3-small.
    FROZEN - Must not change to prevent FAISS index corruption.
    """
    from langchain_openai import OpenAIEmbeddings
    api_key = os.getenv("OPENAI_API_KEY")
    return OpenAIEmbeddings(model="text-embedding-3-small", openai_api_key=api_key)
