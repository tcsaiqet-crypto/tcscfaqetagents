from typing import Dict, Any, Optional
from tools.faiss_retriever import FAISSIndexRetriever, REFUSAL_PHRASE

class AgentManager:
    def __init__(self):
        self.retriever = FAISSIndexRetriever()

    def _is_profile_query(self, user_message: str) -> bool:
        msg_lower = user_message.lower()
        keys = ["profile", "profiles", "candidate type", "candidate types", "persona", "personas"]
        return any(k in msg_lower for k in keys)

    def _profile_catalog_answer(self) -> str:
        return (
            "Available profiles in this app right now:\n\n"
            "- Level I Candidate\n"
            "- Level II Candidate\n"
            "- Level III Candidate\n"
            "- Charterholder View\n"
            "- Admin / Tools User\n\n"
            "If you want, I can also map each profile to available tabs and key actions."
        )

    def _recommend_preset(self, user_message: str) -> str:
        msg = user_message.lower()
        if any(k in msg for k in ["quick", "brief", "short", "tl;dr"]):
            return "concise"
        if any(k in msg for k in ["example", "sample", "demo"]):
            return "examples"
        if any(k in msg for k in ["detail", "deep", "explain", "comprehensive"]):
            return "detailed"
        return "balanced"

    def _apply_preset_and_custom_style(self, chunks: list[str], preset: str, custom_instruction: str = "") -> str:
        if not chunks:
            return REFUSAL_PHRASE

        normalized = (preset or "balanced").lower()
        if normalized == "concise":
            selected = chunks[:1]
        elif normalized == "detailed":
            selected = chunks[:4]
        elif normalized == "examples":
            selected = chunks[:2]
        else:
            selected = chunks[:2]

        body = "\n\n".join([f"- {c.strip()}" for c in selected if c.strip()])
        answer = f"Based on official CFA documentation:\n\n{body}"

        custom = (custom_instruction or "").strip().lower()
        if custom:
            # Keep custom handling deterministic and safe; no instruction can bypass grounded-only answers.
            if "table" in custom:
                rows = [c.strip() for c in selected if c.strip()]
                if rows:
                    table = ["| # | Key Point |", "|---|---|"]
                    for i, r in enumerate(rows, start=1):
                        table.append(f"| {i} | {r.replace('|', '/')} |")
                    answer = "Based on official CFA documentation:\n\n" + "\n".join(table)
            elif "paragraph" in custom:
                answer = "Based on official CFA documentation:\n\n" + " ".join([c.strip() for c in selected if c.strip()])
            elif "short" in custom:
                first = selected[0].strip() if selected else ""
                answer = f"Based on official CFA documentation:\n\n- {first}" if first else REFUSAL_PHRASE

        if normalized == "examples":
            answer += (
                "\n\nExamples you can ask next:\n"
                "- Which profile should I pick for Level I preparation?\n"
                "- What actions are available for Admin / Tools users?"
            )

        return answer

    def _resolve_domain(self, target_agent: str, active_profile: Dict[str, Any]) -> str:
        level = active_profile.get("level_interest") or active_profile.get("level") or "I"
        if target_agent == "tutor":
            return f"curriculum_l{str(level).lower()}"
        if target_agent == "planner":
            return f"curriculum_l{str(level).lower()}"
        return "faq_support"

    def route_request(self, page_context: str, user_message: str) -> str:
        msg_lower = user_message.lower()
        ctx_lower = page_context.lower()

        if self._is_profile_query(user_message):
            return "support"
        
        if "tutor" in ctx_lower or "ethics" in msg_lower or "gips" in msg_lower or "curriculum" in msg_lower or "reading" in msg_lower or "ratio" in msg_lower:
            return "tutor"
        elif "study plan" in ctx_lower or "study plan" in msg_lower or ("planner" in ctx_lower and "hours" in msg_lower):
            return "planner"
        elif "reschedule" in msg_lower or "reschedule" in ctx_lower or "fee" in msg_lower or "register" in msg_lower or "support" in ctx_lower or "ticket" in msg_lower or "slot" in msg_lower or "policy" in msg_lower or "refund" in msg_lower:
            return "support"
        elif "plan" in msg_lower or "schedule" in msg_lower or "hours" in msg_lower:
            return "planner"
        else:
            return "support"

    def process_query(
        self,
        user_message: str,
        page_context: str,
        active_profile: Dict[str, Any],
        provider: str = "openai",
        response_options: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        response_options = response_options or {}

        if self._is_profile_query(user_message):
            answer = self._profile_catalog_answer()
            return {
                "agent_used": "support",
                "domain_queried": "profile_catalog",
                "response": answer,
                "sources": ["app profile model"],
                "model_used": "deterministic"
            }

        target_agent = (response_options.get("agent_override") or "").strip().lower() or self.route_request(page_context, user_message)
        domain = (response_options.get("domain_override") or "").strip() or self._resolve_domain(target_agent, active_profile)
        top_k = int(response_options.get("context_depth") or 4)

        result = self.retriever.retrieve(user_message, agent_role=target_agent, domain=domain, top_k=top_k)

        # Grounded response formatting
        if not result["chunks"] or result["text"] == REFUSAL_PHRASE:
            answer = REFUSAL_PHRASE
            sources = []
            applied_preset = "none"
        else:
            manual_preset = (response_options.get("preset") or "balanced").strip().lower()
            if manual_preset == "auto":
                manual_preset = self._recommend_preset(user_message)
            answer = self._apply_preset_and_custom_style(
                result["chunks"],
                preset=manual_preset,
                custom_instruction=(response_options.get("custom_instruction") or ""),
            )
            sources = result["sources"]
            applied_preset = manual_preset

        return {
            "agent_used": target_agent,
            "domain_queried": domain,
            "response": answer,
            "sources": sources,
            "preset_used": applied_preset,
            "model_used": "gpt-4o" if provider == "openai" else "gemini-2.0-flash"
        }
