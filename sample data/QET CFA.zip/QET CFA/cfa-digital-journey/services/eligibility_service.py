from typing import Dict, Any, Optional
from services.db import get_connection

def check_eligibility(candidate: Dict[str, Any], target_level: str = "I", db_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Deterministic Eligibility Logic:
    - Level I: Requires Bachelor's degree, final year student (within 23 months), OR >=4000 hours work experience over >=36 months.
    - Level II: Requires passed Level I exam in results table.
    - Level III: Requires passed Level II exam in results table.
    """
    # Prerequisite check for Level II and III
    if target_level in ("II", "III"):
        prereq_level = "I" if target_level == "II" else "II"
        conn = get_connection(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM results WHERE candidate_id = ? AND level = ? AND pass_fail = 'pass'", (candidate["id"], prereq_level))
        passed_prereq = cursor.fetchone()
        conn.close()
        
        if not passed_prereq:
            return {
                "eligible": False,
                "reason": f"Must pass CFA Level {prereq_level} before enrolling in Level {target_level}.",
                "target_level": target_level
            }

    # Level I general eligibility criteria
    education = (candidate.get("education") or "").lower()
    work_hours = candidate.get("work_exp_hours") or 0
    work_months = candidate.get("work_exp_months") or 0
    
    is_degree_holder = any(keyword in education for keyword in ["bachelor", "master", "phd", "degree", "bs", "ba", "b.sc", "b.a", "b.com", "b.tech"])
    is_final_year = "final year" in education or "senior" in education
    has_sufficient_work = work_hours >= 4000 and work_months >= 36
    
    if is_degree_holder or is_final_year or has_sufficient_work:
        return {
            "eligible": True,
            "reason": "Meets academic or professional work experience requirements.",
            "target_level": target_level
        }
    else:
        return {
            "eligible": False,
            "reason": "Requires a Bachelor's degree, final-year student status, or at least 4,000 hours of professional work experience over 36 months.",
            "target_level": target_level
        }
