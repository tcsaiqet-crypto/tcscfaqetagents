from datetime import datetime, timezone, timedelta
import uuid
from typing import Dict, Any, Optional, List
from services.db import get_connection

def book_exam_slot(
    candidate_id: int,
    level: str,
    slot_date_str: str, # YYYY-MM-DD
    slot_time: str,
    center_type: str, # center | remote
    center_name: str,
    db_path: Optional[str] = None
) -> Dict[str, Any]:
    """
    Deterministic Exam Scheduling Logic:
    - Retake gap check: Must be at least 6 months apart from previous attempts.
    - Lifetime attempt check: Max 6 attempts per level.
    """
    conn = get_connection(db_path)
    cursor = conn.cursor()
    
    # 1. Lifetime attempts check
    cursor.execute("SELECT COUNT(*) FROM exam_slots WHERE candidate_id = ? AND level = ? AND booking_status IN ('confirmed', 'noshow', 'held')", (candidate_id, level))
    attempt_count = cursor.fetchone()[0]
    if attempt_count >= 6:
        conn.close()
        raise ValueError("Maximum lifetime limit of 6 exam attempts reached for this level.")

    # 2. Retake gap check (6 months)
    cursor.execute("SELECT slot_date FROM exam_slots WHERE candidate_id = ? AND level = ? AND booking_status IN ('confirmed', 'rescheduled') ORDER BY slot_date DESC LIMIT 1", (candidate_id, level))
    last_slot = cursor.fetchone()
    if last_slot and last_slot["slot_date"]:
        try:
            last_date = datetime.strptime(last_slot["slot_date"], "%Y-%m-%d").date()
            new_date = datetime.strptime(slot_date_str, "%Y-%m-%d").date()
            if (new_date - last_date).days < 180:
                conn.close()
                raise ValueError("Exam retakes must be scheduled at least 6 months (180 days) apart.")
        except ValueError as ve:
            if "180 days" in str(ve):
                raise ve

    confirmation_code = f"CONF-{uuid.uuid4().hex[:8].upper()}"
    
    cursor.execute("""
    INSERT INTO exam_slots (candidate_id, level, slot_date, slot_time, center_type, center_name, booking_status, confirmation_code)
    VALUES (?, ?, ?, ?, ?, ?, 'confirmed', ?)
    """, (candidate_id, level, slot_date_str, slot_time, center_type, center_name, confirmation_code))
    
    slot_id = cursor.lastrowid
    
    # Write audit log
    cursor.execute("""
    INSERT INTO audit_log (timestamp, candidate_id, action_type, entity, entity_id, performed_by, page, extra_json)
    VALUES (?, ?, 'book_slot', 'exam_slots', ?, 'system', 'Explore & Enroll', ?)
    """, (datetime.now(timezone.utc).isoformat(), candidate_id, str(slot_id), f'{{"code": "{confirmation_code}", "date": "{slot_date_str}"}}'))
    
    conn.commit()
    conn.close()
    
    return {
        "slot_id": slot_id,
        "candidate_id": candidate_id,
        "level": level,
        "slot_date": slot_date_str,
        "slot_time": slot_time,
        "center_type": center_type,
        "center_name": center_name,
        "booking_status": "confirmed",
        "confirmation_code": confirmation_code
    }

def reschedule_exam_slot(
    slot_id: int,
    new_date_str: str,
    new_time: str,
    db_path: Optional[str] = None
) -> Dict[str, Any]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM exam_slots WHERE id = ?", (slot_id,))
    slot = cursor.fetchone()
    if not slot:
        conn.close()
        raise ValueError("Exam slot not found.")
        
    reschedule_fee = 250.0
    cancelled_at = datetime.now(timezone.utc).isoformat()
    
    # Mark old slot as rescheduled
    cursor.execute("UPDATE exam_slots SET booking_status = 'rescheduled', cancelled_at = ? WHERE id = ?", (cancelled_at, slot_id))
    
    # Book new slot
    new_code = f"CONF-{uuid.uuid4().hex[:8].upper()}"
    cursor.execute("""
    INSERT INTO exam_slots (candidate_id, level, slot_date, slot_time, center_type, center_name, booking_status, confirmation_code, rescheduled_from, reschedule_fee)
    VALUES (?, ?, ?, ?, ?, ?, 'confirmed', ?, ?, ?)
    """, (slot["candidate_id"], slot["level"], new_date_str, new_time, slot["center_type"], slot["center_name"], new_code, slot_id, reschedule_fee))
    
    new_slot_id = cursor.lastrowid
    conn.commit()
    conn.close()
    
    return {
        "new_slot_id": new_slot_id,
        "old_slot_id": slot_id,
        "reschedule_fee": reschedule_fee,
        "confirmation_code": new_code,
        "status": "confirmed"
    }

def get_candidate_slots(candidate_id: int, db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM exam_slots WHERE candidate_id = ? ORDER BY id DESC", (candidate_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]
