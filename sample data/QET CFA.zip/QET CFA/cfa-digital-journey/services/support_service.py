from datetime import datetime, timezone
from typing import Dict, Any, Optional, List
from services.db import get_connection

def create_support_ticket(
    candidate_id: int,
    subject: str,
    description: str,
    priority: str = "normal", # low | normal | high
    page_context: str = "Help & Support",
    db_path: Optional[str] = None
) -> Dict[str, Any]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    created_at = datetime.now(timezone.utc).isoformat()
    
    cursor.execute("""
    INSERT INTO support_tickets (candidate_id, created_at, subject, description, status, priority, page_context)
    VALUES (?, ?, ?, ?, 'open', ?, ?)
    """, (candidate_id, created_at, subject, description, priority, page_context))
    
    ticket_id = cursor.lastrowid
    
    # Audit log
    cursor.execute("""
    INSERT INTO audit_log (timestamp, candidate_id, action_type, entity, entity_id, performed_by, page)
    VALUES (?, ?, 'create_ticket', 'support_tickets', ?, 'system', ?)
    """, (created_at, candidate_id, str(ticket_id), page_context))
    
    conn.commit()
    conn.close()
    
    return {
        "ticket_id": ticket_id,
        "candidate_id": candidate_id,
        "subject": subject,
        "description": description,
        "status": "open",
        "priority": priority,
        "created_at": created_at
    }

def get_candidate_tickets(candidate_id: int, db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM support_tickets WHERE candidate_id = ? ORDER BY ticket_id DESC", (candidate_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]
