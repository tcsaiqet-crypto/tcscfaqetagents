from datetime import datetime, timezone
import hashlib
import uuid
from typing import Dict, Any, Optional, List
from services.db import get_connection

def generate_candidate_id() -> str:
    year = datetime.now().year
    suffix = str(uuid.uuid4().int)[:5]
    return f"CFA-{year}-{suffix}"

def register_candidate(
    name: str,
    email: str,
    password: str,
    sso_provider: Optional[str] = None,
    db_path: Optional[str] = None
) -> Dict[str, Any]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    
    # Check email uniqueness
    cursor.execute("SELECT id FROM candidates WHERE email = ?", (email,))
    if cursor.fetchone():
        conn.close()
        raise ValueError(f"Email {email} is already registered.")
        
    cand_id = generate_candidate_id()
    pwd_hash = hashlib.sha256(password.encode("utf-8")).hexdigest() if password else None
    created_at = datetime.now(timezone.utc).isoformat()
    
    cursor.execute("""
    INSERT INTO candidates (candidate_id, name, email, password_hash, created_at, kyc_status, profile_type, role)
    VALUES (?, ?, ?, ?, ?, 'pending', 'candidate', 'candidate')
    """, (cand_id, name, email, pwd_hash, created_at))
    
    row_id = cursor.lastrowid
    
    # Audit log
    cursor.execute("""
    INSERT INTO audit_log (timestamp, candidate_id, action_type, entity, entity_id, performed_by, page)
    VALUES (?, ?, 'register', 'candidate', ?, 'system', 'My Profile')
    """, (created_at, row_id, str(row_id)))
    
    conn.commit()
    conn.close()
    
    return get_candidate_by_id(row_id, db_path)

def get_candidate_by_id(candidate_db_id: int, db_path: Optional[str] = None) -> Dict[str, Any]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM candidates WHERE id = ?", (candidate_db_id,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        raise ValueError(f"Candidate with ID {candidate_db_id} not found.")
    return dict(row)

def get_candidate_by_custom_id(custom_id: str, db_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM candidates WHERE candidate_id = ?", (custom_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None

def get_all_candidates(db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM candidates ORDER BY id ASC")
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]

def update_profile(
    candidate_db_id: int,
    education: str,
    institution: str,
    graduation_year: int,
    work_exp_hours: int,
    employment_status: str,
    level_interest: str,
    target_exam_date: str,
    study_hours_week: int,
    knowledge_level: str,
    db_path: Optional[str] = None
) -> Dict[str, Any]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    updated_at = datetime.now(timezone.utc).isoformat()
    
    cursor.execute("""
    UPDATE candidates
    SET education = ?,
        institution = ?,
        graduation_year = ?,
        work_exp_hours = ?,
        employment_status = ?,
        level_interest = ?,
        target_exam_date = ?,
        study_hours_week = ?,
        knowledge_level = ?,
        updated_at = ?
    WHERE id = ?
    """, (
        education, institution, graduation_year, work_exp_hours,
        employment_status, level_interest, target_exam_date,
        study_hours_week, knowledge_level, updated_at, candidate_db_id
    ))
    
    conn.commit()
    conn.close()
    return get_candidate_by_id(candidate_db_id, db_path)

def calculate_profile_completeness(candidate: Dict[str, Any]) -> int:
    fields = [
        "name", "email", "education", "institution", "graduation_year",
        "work_exp_hours", "level_interest", "target_exam_date", "study_hours_week"
    ]
    completed = sum(1 for f in fields if candidate.get(f) is not None and candidate.get(f) != "")
    return int((completed / len(fields)) * 100)
