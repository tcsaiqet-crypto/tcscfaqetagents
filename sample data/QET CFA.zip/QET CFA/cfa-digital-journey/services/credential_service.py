from datetime import datetime, timezone
import uuid
from typing import Dict, Any, Optional
from services.db import get_connection

def issue_certificate(
    candidate_id: int,
    level: str,
    db_path: Optional[str] = None
) -> Dict[str, Any]:
    """
    Deterministic Digital Certificate Engine:
    - Generates unique tamper-proof verification_code.
    - Generates LinkedIn share URL stub and badge card URL.
    - Updates certificate_id in results table if result exists.
    """
    conn = get_connection(db_path)
    cursor = conn.cursor()
    
    cert_id = f"CERT-{uuid.uuid4().hex[:8].upper()}"
    verification_code = f"VERIFY-{uuid.uuid4().hex[:12].upper()}"
    issued_at = datetime.now(timezone.utc).isoformat()
    
    linkedin_url = f"https://www.linkedin.com/profile/add?startTask=CERTIFICATION_NAME&name=CFA%20{level}%20Passed&organizationName=CFA%20Institute&issueYear=2026&certUrl=https://cfainstitute.org/verify/{verification_code}"
    badge_url = f"https://badges.cfainstitute.org/{cert_id}.png"
    
    cursor.execute("""
    INSERT INTO certificates (certificate_id, candidate_id, level, issued_at, verification_code, linkedin_url, badge_url, verified_count)
    VALUES (?, ?, ?, ?, ?, ?, ?, 0)
    """, (cert_id, candidate_id, level, issued_at, verification_code, linkedin_url, badge_url))
    
    # Update result record if exists
    cursor.execute("UPDATE results SET certificate_id = ? WHERE candidate_id = ? AND level = ? AND pass_fail = 'pass'", (cert_id, candidate_id, level))
    
    # Audit log
    cursor.execute("""
    INSERT INTO audit_log (timestamp, candidate_id, action_type, entity, entity_id, performed_by, page, extra_json)
    VALUES (?, ?, 'issue_certificate', 'certificates', ?, 'system', 'My Credentials', ?)
    """, (issued_at, candidate_id, cert_id, f'{{"verification_code": "{verification_code}"}}'))
    
    conn.commit()
    conn.close()
    
    return {
        "certificate_id": cert_id,
        "candidate_id": candidate_id,
        "level": level,
        "issued_at": issued_at,
        "verification_code": verification_code,
        "linkedin_url": linkedin_url,
        "badge_url": badge_url
    }

def verify_credential(verification_code: str, db_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Public Third-Party Verification Lookup Endpoint:
    Increments verified_count on valid match.
    """
    conn = get_connection(db_path)
    cursor = conn.cursor()
    
    cursor.execute("""
    SELECT c.*, cand.name as candidate_name, cand.email
    FROM certificates c
    JOIN candidates cand ON c.candidate_id = cand.id
    WHERE c.verification_code = ?
    """, (verification_code,))
    
    row = cursor.fetchone()
    if not row:
        conn.close()
        return {"valid": False, "reason": "Verification code not found or invalid."}
        
    cert_id = row["certificate_id"]
    cursor.execute("UPDATE certificates SET verified_count = verified_count + 1 WHERE certificate_id = ?", (cert_id,))
    
    conn.commit()
    conn.close()
    
    return {
        "valid": True,
        "certificate_id": cert_id,
        "candidate_name": row["candidate_name"],
        "level": row["level"],
        "issued_at": row["issued_at"],
        "verification_code": row["verification_code"],
        "verified_count": row["verified_count"] + 1
    }

def is_charterholder(candidate_id: int, db_path: Optional[str] = None) -> bool:
    """
    Checks if candidate has passed all three levels (Level I, Level II, Level III).
    """
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(DISTINCT level) FROM results WHERE candidate_id = ? AND pass_fail = 'pass'", (candidate_id,))
    count = cursor.fetchone()[0]
    conn.close()
    return count >= 3
