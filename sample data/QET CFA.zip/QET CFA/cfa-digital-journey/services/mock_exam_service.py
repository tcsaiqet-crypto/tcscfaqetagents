from datetime import datetime, timezone
import json
from typing import Dict, Any, Optional, List
from services.db import get_connection

def evaluate_mock_exam(
    candidate_id: int,
    exam_id: str,
    level: str,
    answers: Dict[str, str], # question_id -> candidate_selected_option
    db_path: Optional[str] = None
) -> Dict[str, Any]:
    """
    Automated Mock Exam Scoring Engine:
    - Fetches questions from DB.
    - Evaluates correct answers.
    - Calculates overall score % and topic-level performance breakdown.
    - Identifies weak areas (topics with score < 70%).
    """
    conn = get_connection(db_path)
    cursor = conn.cursor()
    
    total_questions = len(answers)
    correct_count = 0
    topic_stats = {} # topic -> {total, correct}
    
    for q_id, selected_opt in answers.items():
        cursor.execute("SELECT topic, correct_option FROM questions WHERE question_id = ?", (q_id,))
        row = cursor.fetchone()
        topic = row["topic"] if row else "General"
        correct_opt = row["correct_option"] if row else None
        
        if topic not in topic_stats:
            topic_stats[topic] = {"total": 0, "correct": 0}
            
        topic_stats[topic]["total"] += 1
        if correct_opt and selected_opt.upper() == correct_opt.upper():
            correct_count += 1
            topic_stats[topic]["correct"] += 1
            
    score_pct = round((correct_count / total_questions * 100.0), 1) if total_questions > 0 else 0.0
    
    topic_breakdown = {}
    weak_areas = []
    
    for top, stats in topic_stats.items():
        top_pct = round((stats["correct"] / stats["total"] * 100.0), 1)
        topic_breakdown[top] = {
            "score_pct": top_pct,
            "correct": stats["correct"],
            "total": stats["total"]
        }
        if top_pct < 70.0:
            weak_areas.append(top)
            
    started_at = datetime.now(timezone.utc).isoformat()
    submitted_at = datetime.now(timezone.utc).isoformat()
    
    cursor.execute("""
    INSERT INTO mock_exams (candidate_id, exam_id, level, attempt_number, started_at, submitted_at, total_questions, correct_answers, score_pct, topic_breakdown, weak_areas, timed)
    VALUES (?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, 0)
    """, (candidate_id, exam_id, level, started_at, submitted_at, total_questions, correct_count, score_pct, json.dumps(topic_breakdown), json.dumps(weak_areas)))
    
    exam_db_id = cursor.lastrowid
    
    # Audit log
    cursor.execute("""
    INSERT INTO audit_log (timestamp, candidate_id, action_type, entity, entity_id, performed_by, page, extra_json)
    VALUES (?, ?, 'mock_exam_submit', 'mock_exams', ?, 'system', 'Study Room', ?)
    """, (submitted_at, candidate_id, str(exam_db_id), f'{{"score_pct": {score_pct}, "weak_areas": {json.dumps(weak_areas)}}}'))
    
    conn.commit()
    conn.close()
    
    return {
        "id": exam_db_id,
        "candidate_id": candidate_id,
        "exam_id": exam_id,
        "total_questions": total_questions,
        "correct_answers": correct_count,
        "score_pct": score_pct,
        "topic_breakdown": topic_breakdown,
        "weak_areas": weak_areas,
        "submitted_at": submitted_at
    }

def get_candidate_mock_history(candidate_id: int, db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM mock_exams WHERE candidate_id = ? ORDER BY id DESC", (candidate_id,))
    rows = cursor.fetchall()
    conn.close()
    
    results = []
    for r in rows:
        d = dict(r)
        d["topic_breakdown"] = json.loads(d["topic_breakdown"]) if d.get("topic_breakdown") else {}
        d["weak_areas"] = json.loads(d["weak_areas"]) if d.get("weak_areas") else []
        results.append(d)
    return results
