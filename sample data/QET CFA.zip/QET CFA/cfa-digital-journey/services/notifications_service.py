from datetime import datetime, timezone
from typing import Dict, Any, Optional, List
from services.db import get_connection

def get_notification_preferences(candidate_id: int, db_path: Optional[str] = None) -> Dict[str, Any]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM notification_preferences WHERE candidate_id = ?", (candidate_id,))
    row = cursor.fetchone()
    if not row:
        cursor.execute("""
        INSERT INTO notification_preferences (candidate_id, email_enabled, sms_enabled, push_enabled, inapp_enabled, frequency)
        VALUES (?, 0, 0, 0, 1, 'immediate')
        """, (candidate_id,))
        conn.commit()
        cursor.execute("SELECT * FROM notification_preferences WHERE candidate_id = ?", (candidate_id,))
        row = cursor.fetchone()
    conn.close()
    return dict(row)

def update_notification_preferences(
    candidate_id: int,
    inapp: bool = True,
    email: bool = False,
    sms: bool = False,
    push: bool = False,
    db_path: Optional[str] = None
) -> Dict[str, Any]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("""
    INSERT INTO notification_preferences (candidate_id, inapp_enabled, email_enabled, sms_enabled, push_enabled)
    VALUES (?, ?, ?, ?, ?)
    ON CONFLICT(candidate_id) DO UPDATE SET
        inapp_enabled = excluded.inapp_enabled,
        email_enabled = excluded.email_enabled,
        sms_enabled = excluded.sms_enabled,
        push_enabled = excluded.push_enabled
    """, (candidate_id, int(inapp), int(email), int(sms), int(push)))
    conn.commit()
    conn.close()
    return get_notification_preferences(candidate_id, db_path)

def send_notification(
    candidate_id: int,
    title: str,
    body: str,
    type_code: str = "general",
    channel: str = "inapp",
    db_path: Optional[str] = None
) -> Optional[Dict[str, Any]]:
    prefs = get_notification_preferences(candidate_id, db_path)
    
    # Check if channel is enabled
    if channel == "inapp" and not prefs.get("inapp_enabled", 1):
        return None
    elif channel == "email" and not prefs.get("email_enabled", 0):
        return None
        
    conn = get_connection(db_path)
    cursor = conn.cursor()
    sent_at = datetime.now(timezone.utc).isoformat()
    
    cursor.execute("""
    INSERT INTO notifications (candidate_id, type, channel, title, body, sent_at, status)
    VALUES (?, ?, ?, ?, ?, ?, 'sent')
    """, (candidate_id, type_code, channel, title, body, sent_at))
    
    n_id = cursor.lastrowid
    conn.commit()
    conn.close()
    
    return {
        "notification_id": n_id,
        "candidate_id": candidate_id,
        "title": title,
        "body": body,
        "sent_at": sent_at
    }

def get_candidate_inbox(candidate_id: int, db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM notifications WHERE candidate_id = ? ORDER BY notification_id DESC", (candidate_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]
