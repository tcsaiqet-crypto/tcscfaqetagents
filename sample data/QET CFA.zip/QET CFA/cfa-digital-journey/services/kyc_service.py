from datetime import datetime, timezone
import hashlib
from typing import Dict, Any, Optional, List
from services.db import get_connection

def verify_identity(
    candidate_db_id: int,
    id_type: str,
    doc_number: str,
    expiry_date_str: str, # YYYY-MM-DD
    liveness_score: float, # 0.0 to 100.0
    db_path: Optional[str] = None
) -> Dict[str, Any]:
    """
    Deterministic KYC Evaluation Engine:
    - Expiry check: Must be >= current date.
    - Liveness score: >= 80.0 -> VERIFIED
    - Liveness score: 50.0 to 79.9 or Expired ID -> REQUIRES_MANUAL_REVIEW
    - Liveness score: < 50.0 -> REJECTED
    """
    conn = get_connection(db_path)
    cursor = conn.cursor()
    
    verified_at = datetime.now(timezone.utc).isoformat()
    doc_hash = hashlib.sha256(doc_number.encode("utf-8")).hexdigest()[:16]
    
    # Check expiry
    is_expired = False
    try:
        exp_date = datetime.strptime(expiry_date_str, "%Y-%m-%d").date()
        if exp_date < datetime.now(timezone.utc).date():
            is_expired = True
    except Exception:
        is_expired = True
        
    status = "VERIFIED"
    failure_reason = None
    
    if is_expired:
        status = "REQUIRES_MANUAL_REVIEW"
        failure_reason = "Document expired or invalid expiry date format."
    elif liveness_score >= 80.0:
        status = "VERIFIED"
    elif 50.0 <= liveness_score < 80.0:
        status = "REQUIRES_MANUAL_REVIEW"
        failure_reason = f"Liveness score ({liveness_score}%) below 80% threshold."
    else:
        status = "REJECTED"
        failure_reason = f"Liveness score ({liveness_score}%) critical failure (<50%)."
        
    # Record verification in kyc_verifications
    cursor.execute("""
    INSERT INTO kyc_verifications (candidate_id, id_type, document_number_hash, expiry_date, liveness_score, status, failure_reason, verified_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, (candidate_db_id, id_type, doc_hash, expiry_date_str, liveness_score, status, failure_reason, verified_at))
    
    # Update candidate table kyc_status
    cursor.execute("""
    UPDATE candidates SET kyc_status = ?, updated_at = ? WHERE id = ?
    """, (status, verified_at, candidate_db_id))
    
    # Write audit log
    cursor.execute("""
    INSERT INTO audit_log (timestamp, candidate_id, action_type, entity, entity_id, old_value, new_value, performed_by, page, extra_json)
    VALUES (?, ?, 'kyc_verification', 'candidate', ?, 'pending', ?, 'system', 'My Profile', ?)
    """, (verified_at, candidate_db_id, str(candidate_db_id), status, f'{{"liveness_score": {liveness_score}, "failure_reason": "{failure_reason}"}}'))
    
    conn.commit()
    conn.close()
    
    return {
        "candidate_id": candidate_db_id,
        "status": status,
        "liveness_score": liveness_score,
        "failure_reason": failure_reason,
        "verified_at": verified_at
    }

def get_kyc_history(candidate_db_id: int, db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM kyc_verifications WHERE candidate_id = ? ORDER BY verification_id DESC", (candidate_db_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(r) for r in rows]
