from datetime import datetime, timezone
import base64
import json
import uuid
from typing import Dict, Any, Optional, List
from services.db import get_connection

def launch_exam_session(
    candidate_id: int,
    level: str,
    db_path: Optional[str] = None
) -> Dict[str, Any]:
    """
    Identity Re-Verification Launch Gate:
    - Candidate must exist and have kyc_status == 'VERIFIED'
    - Candidate must have a confirmed slot in exam_slots
    """
    conn = get_connection(db_path)
    cursor = conn.cursor()
    
    # Check candidate KYC status
    cursor.execute("SELECT kyc_status FROM candidates WHERE id = ?", (candidate_id,))
    cand = cursor.fetchone()
    if not cand or cand["kyc_status"] != "VERIFIED":
        conn.close()
        raise ValueError("Identity re-verification failed. KYC status must be VERIFIED to launch exam.")
        
    # Check confirmed slot
    cursor.execute("SELECT id FROM exam_slots WHERE candidate_id = ? AND level = ? AND booking_status = 'confirmed'", (candidate_id, level))
    slot = cursor.fetchone()
    if not slot:
        conn.close()
        raise ValueError(f"No confirmed exam slot booking found for Level {level}.")
        
    session_id = f"SESS-{uuid.uuid4().hex[:8].upper()}"
    started_at = datetime.now(timezone.utc).isoformat()
    
    cursor.execute("""
    INSERT INTO exam_sessions (candidate_id, level, session_id, started_at, proctoring_log, integrity_flags, status)
    VALUES (?, ?, ?, ?, '[]', '[]', 'in_progress')
    """, (candidate_id, level, session_id, started_at))
    
    db_id = cursor.lastrowid
    
    # Audit log
    cursor.execute("""
    INSERT INTO audit_log (timestamp, candidate_id, action_type, entity, entity_id, performed_by, page)
    VALUES (?, ?, 'exam_launch', 'exam_sessions', ?, 'system', 'Exam Center')
    """, (started_at, candidate_id, str(db_id)))
    
    conn.commit()
    conn.close()
    
    return {
        "id": db_id,
        "session_id": session_id,
        "candidate_id": candidate_id,
        "level": level,
        "status": "in_progress",
        "started_at": started_at
    }

def log_proctoring_event(
    session_id: str,
    event_type: str, # 'face_missing' | 'secondary_voice' | 'prohibited_item'
    duration_seconds: float,
    details: str,
    db_path: Optional[str] = None
) -> Dict[str, Any]:
    """
    Deterministic Synthetic Proctoring Event Logger:
    - Logs events to proctoring_log JSON.
    - If face_missing > 5s or secondary_voice -> adds integrity flag.
    """
    conn = get_connection(db_path)
    cursor = conn.cursor()
    
    cursor.execute("SELECT * FROM exam_sessions WHERE session_id = ?", (session_id,))
    session = cursor.fetchone()
    if not session:
        conn.close()
        raise ValueError("Exam session not found.")
        
    log_list = json.loads(session["proctoring_log"]) if session["proctoring_log"] else []
    flag_list = json.loads(session["integrity_flags"]) if session["integrity_flags"] else []
    
    now_str = datetime.now(timezone.utc).isoformat()
    new_event = {
        "timestamp": now_str,
        "event_type": event_type,
        "duration_seconds": duration_seconds,
        "details": details
    }
    log_list.append(new_event)
    
    # Check threshold rules
    if (event_type == "face_missing" and duration_seconds > 5.0) or event_type in ("secondary_voice", "prohibited_item"):
        flag_list.append({
            "flag_id": f"FLAG-{uuid.uuid4().hex[:6].upper()}",
            "timestamp": now_str,
            "rule_violated": event_type,
            "severity": "high" if duration_seconds > 10.0 else "medium"
        })
        
    cursor.execute("""
    UPDATE exam_sessions
    SET proctoring_log = ?, integrity_flags = ?
    WHERE session_id = ?
    """, (json.dumps(log_list), json.dumps(flag_list), session_id))
    
    conn.commit()
    conn.close()
    
    return {
        "session_id": session_id,
        "events_count": len(log_list),
        "flags_count": len(flag_list),
        "latest_flagged": len(flag_list) > 0
    }

def submit_exam_responses(
    session_id: str,
    raw_responses: Dict[str, str],
    db_path: Optional[str] = None
) -> Dict[str, Any]:
    """
    Encrypted Response Payload Submission:
    - Encrypts response dict to base64 blob.
    - Sets session status to 'submitted'.
    """
    conn = get_connection(db_path)
    cursor = conn.cursor()
    
    submitted_at = datetime.now(timezone.utc).isoformat()
    resp_json = json.dumps(raw_responses)
    encrypted_blob = base64.b64encode(resp_json.encode("utf-8")).decode("utf-8")
    
    cursor.execute("""
    UPDATE exam_sessions
    SET status = 'submitted', submitted_at = ?, encrypted_responses = ?
    WHERE session_id = ?
    """, (submitted_at, encrypted_blob, session_id))
    
    cursor.execute("SELECT candidate_id FROM exam_sessions WHERE session_id = ?", (session_id,))
    row = cursor.fetchone()
    cand_id = row["candidate_id"] if row else None
    
    # Audit log
    cursor.execute("""
    INSERT INTO audit_log (timestamp, candidate_id, action_type, entity, entity_id, performed_by, page)
    VALUES (?, ?, 'exam_submit', 'exam_sessions', ?, 'system', 'Exam Center')
    """, (submitted_at, cand_id, session_id))
    
    conn.commit()
    conn.close()
    
    return {
        "session_id": session_id,
        "status": "submitted",
        "submitted_at": submitted_at,
        "responses_encrypted": True
    }
