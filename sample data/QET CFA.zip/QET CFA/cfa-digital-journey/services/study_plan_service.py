from datetime import datetime, timezone
from typing import Dict, Any, Optional, List
from services.db import get_connection

LEVEL_1_TOPICS = [
    "Ethical and Professional Standards",
    "Quantitative Methods",
    "Economics",
    "Financial Statement Analysis",
    "Corporate Issuers",
    "Equity Investments",
    "Fixed Income",
    "Derivatives",
    "Alternative Investments",
    "Portfolio Management"
]

def generate_default_study_plan(
    candidate_id: int,
    level: str = "I",
    target_exam_date: str = "2026-02-15",
    study_hours_week: int = 10,
    db_path: Optional[str] = None
) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    
    # Clear existing plan for level
    cursor.execute("DELETE FROM study_plans WHERE candidate_id = ? AND level = ?", (candidate_id, level))
    
    topics = LEVEL_1_TOPICS
    hours_per_topic = 20.0
    now_str = datetime.now(timezone.utc).isoformat()
    
    plan_rows = []
    for idx, topic in enumerate(topics, start=1):
        week_num = (idx + 1) // 2
        cursor.execute("""
        INSERT INTO study_plans (candidate_id, level, topic, week_number, sort_order, planned_hours, status, source, modified_at, modified_by)
        VALUES (?, ?, ?, ?, ?, ?, 'planned', 'ai_suggested', ?, 'seed')
        """, (candidate_id, level, topic, week_num, idx, hours_per_topic, now_str))
        
        row_id = cursor.lastrowid
        plan_rows.append({
            "id": row_id,
            "candidate_id": candidate_id,
            "level": level,
            "topic": topic,
            "week_number": week_num,
            "sort_order": idx,
            "planned_hours": hours_per_topic,
            "status": "planned",
            "source": "ai_suggested"
        })
        
    conn.commit()
    conn.close()
    return plan_rows

def get_study_plan(candidate_id: int, level: str = "I", db_path: Optional[str] = None) -> List[Dict[str, Any]]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM study_plans WHERE candidate_id = ? AND level = ? ORDER BY sort_order ASC", (candidate_id, level))
    rows = cursor.fetchall()
    conn.close()
    if not rows:
        return generate_default_study_plan(candidate_id, level, db_path=db_path)
    return [dict(r) for r in rows]

def update_study_plan_order(
    candidate_id: int,
    level: str,
    reordered_topic_ids: List[int],
    modified_by: str = "drag", # 'drag' | 'chat' | 'manual'
    db_path: Optional[str] = None
) -> List[Dict[str, Any]]:
    """
    Conflict Resolution: Last Action Wins Policy.
    Updates sort_order, modified_at, and modified_by for all topics.
    """
    conn = get_connection(db_path)
    cursor = conn.cursor()
    now_str = datetime.now(timezone.utc).isoformat()
    
    for new_order, plan_id in enumerate(reordered_topic_ids, start=1):
        cursor.execute("""
        UPDATE study_plans
        SET sort_order = ?, modified_at = ?, modified_by = ?, source = ?
        WHERE id = ? AND candidate_id = ?
        """, (new_order, now_str, modified_by, modified_by, plan_id, candidate_id))
        
    conn.commit()
    conn.close()
    return get_study_plan(candidate_id, level, db_path=db_path)
