import os
import sqlite3
from typing import Optional

DEFAULT_DB_PATH = os.path.join("data", "cfa_journey.db")

def get_db_path() -> str:
    return os.getenv("DATABASE_PATH", DEFAULT_DB_PATH)

def get_connection(db_path: Optional[str] = None) -> sqlite3.Connection:
    path = db_path or get_db_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    return conn

def init_db(db_path: Optional[str] = None) -> None:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    
    # 1. candidates
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS candidates (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        candidate_id TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT,
        education TEXT,
        institution TEXT,
        graduation_year INTEGER,
        work_exp_hours INTEGER DEFAULT 0,
        work_exp_months INTEGER DEFAULT 0,
        employment_status TEXT,
        level_interest TEXT CHECK(level_interest IN ('I', 'II', 'III')),
        target_exam_date TEXT,
        study_hours_week INTEGER DEFAULT 10,
        knowledge_level TEXT,
        kyc_status TEXT DEFAULT 'pending',
        profile_type TEXT DEFAULT 'candidate',
        role TEXT DEFAULT 'candidate',
        created_at TEXT NOT NULL,
        updated_at TEXT,
        consent_flags TEXT,
        notes TEXT
    )
    """)
    
    # 2. enrollments
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS enrollments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        candidate_id INTEGER NOT NULL REFERENCES candidates(id),
        level TEXT NOT NULL,
        status TEXT,
        payment_status TEXT,
        payment_amount REAL,
        payment_currency TEXT DEFAULT 'USD',
        payment_method TEXT,
        enrolled_at TEXT,
        receipt_id TEXT,
        fee_window TEXT,
        registration_year INTEGER
    )
    """)
    
    # 3. exam_slots
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS exam_slots (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        candidate_id INTEGER NOT NULL REFERENCES candidates(id),
        level TEXT NOT NULL,
        slot_date TEXT,
        slot_time TEXT,
        center_type TEXT,
        center_name TEXT,
        booking_status TEXT,
        confirmation_code TEXT UNIQUE,
        rescheduled_from INTEGER,
        cancelled_at TEXT,
        reschedule_fee REAL DEFAULT 0
    )
    """)
    
    # 4. study_plans
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS study_plans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        candidate_id INTEGER NOT NULL REFERENCES candidates(id),
        level TEXT NOT NULL,
        topic TEXT NOT NULL,
        subtopic TEXT,
        week_number INTEGER,
        sort_order INTEGER,
        planned_hours REAL,
        status TEXT DEFAULT 'planned',
        source TEXT DEFAULT 'ai_suggested',
        modified_at TEXT,
        modified_by TEXT
    )
    """)
    
    # 5. content_progress
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS content_progress (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        candidate_id INTEGER NOT NULL REFERENCES candidates(id),
        level TEXT,
        reading_id TEXT,
        reading_title TEXT,
        topic TEXT,
        completion_pct REAL DEFAULT 0,
        time_spent_minutes INTEGER DEFAULT 0,
        last_accessed TEXT
    )
    """)
    
    # 6. mock_exams
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS mock_exams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        candidate_id INTEGER NOT NULL REFERENCES candidates(id),
        exam_id TEXT,
        level TEXT,
        attempt_number INTEGER,
        started_at TEXT,
        submitted_at TEXT,
        total_questions INTEGER,
        correct_answers INTEGER,
        score_pct REAL,
        topic_breakdown TEXT,
        weak_areas TEXT,
        timed INTEGER DEFAULT 0
    )
    """)
    
    # 7. questions
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS questions (
        question_id TEXT PRIMARY KEY,
        level TEXT,
        topic TEXT,
        subtopic TEXT,
        difficulty TEXT,
        question_text TEXT NOT NULL,
        option_a TEXT,
        option_b TEXT,
        option_c TEXT,
        option_d TEXT,
        correct_option TEXT,
        explanation TEXT,
        los_reference TEXT
    )
    """)
    
    # 8. exam_sessions
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS exam_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        candidate_id INTEGER NOT NULL REFERENCES candidates(id),
        level TEXT,
        session_id TEXT UNIQUE,
        started_at TEXT,
        submitted_at TEXT,
        proctoring_log TEXT,
        integrity_flags TEXT,
        status TEXT,
        encrypted_responses TEXT
    )
    """)
    
    # 9. results
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        candidate_id INTEGER NOT NULL REFERENCES candidates(id),
        level TEXT,
        result_id TEXT UNIQUE,
        released_at TEXT,
        pass_fail TEXT,
        topic_bands TEXT,
        score_relative_to_mps TEXT,
        certificate_id TEXT
    )
    """)
    
    # 10. certificates
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS certificates (
        certificate_id TEXT PRIMARY KEY,
        candidate_id INTEGER NOT NULL REFERENCES candidates(id),
        level TEXT,
        issued_at TEXT,
        verification_code TEXT UNIQUE,
        linkedin_url TEXT,
        badge_url TEXT,
        verified_count INTEGER DEFAULT 0
    )
    """)
    
    # 11. notifications
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS notifications (
        notification_id INTEGER PRIMARY KEY AUTOINCREMENT,
        candidate_id INTEGER NOT NULL REFERENCES candidates(id),
        type TEXT,
        channel TEXT DEFAULT 'inapp',
        title TEXT,
        body TEXT,
        sent_at TEXT,
        read_at TEXT,
        status TEXT DEFAULT 'sent'
    )
    """)
    
    # 12. notification_preferences
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS notification_preferences (
        candidate_id INTEGER PRIMARY KEY REFERENCES candidates(id),
        email_enabled INTEGER DEFAULT 0,
        sms_enabled INTEGER DEFAULT 0,
        push_enabled INTEGER DEFAULT 0,
        inapp_enabled INTEGER DEFAULT 1,
        frequency TEXT DEFAULT 'immediate'
    )
    """)
    
    # 13. support_tickets
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS support_tickets (
        ticket_id INTEGER PRIMARY KEY AUTOINCREMENT,
        candidate_id INTEGER NOT NULL REFERENCES candidates(id),
        created_at TEXT,
        subject TEXT,
        description TEXT,
        status TEXT DEFAULT 'open',
        priority TEXT DEFAULT 'normal',
        resolved_at TEXT,
        resolution_notes TEXT,
        assigned_to TEXT,
        page_context TEXT
    )
    """)
    
    # 14. chat_sessions
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS chat_sessions (
        session_id TEXT PRIMARY KEY,
        candidate_id INTEGER NOT NULL REFERENCES candidates(id),
        page_context TEXT,
        started_at TEXT,
        ended_at TEXT,
        message_count INTEGER DEFAULT 0,
        file_path TEXT
    )
    """)
    
    # 15. audit_log
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS audit_log (
        log_id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT NOT NULL,
        candidate_id INTEGER,
        action_type TEXT,
        entity TEXT,
        entity_id TEXT,
        old_value TEXT,
        new_value TEXT,
        performed_by TEXT,
        agent_used TEXT,
        model_used TEXT,
        page TEXT,
        extra_json TEXT
    )
    """)
    
    # 16. content_library
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS content_library (
        content_id TEXT PRIMARY KEY,
        level TEXT,
        topic TEXT,
        subtopic TEXT,
        reading_id TEXT,
        title TEXT,
        content_type TEXT,
        url_or_path TEXT,
        duration_minutes INTEGER
    )
    """)
    
    # 17. kyc_verifications
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS kyc_verifications (
        verification_id INTEGER PRIMARY KEY AUTOINCREMENT,
        candidate_id INTEGER NOT NULL REFERENCES candidates(id),
        id_type TEXT NOT NULL,
        document_number_hash TEXT,
        expiry_date TEXT,
        liveness_score REAL,
        status TEXT NOT NULL,
        failure_reason TEXT,
        verified_at TEXT NOT NULL
    )
    """)
    
    conn.commit()
    conn.close()
