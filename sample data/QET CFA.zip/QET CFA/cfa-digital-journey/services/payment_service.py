from datetime import datetime, timezone
import uuid
from typing import Dict, Any, Optional
from services.db import get_connection

def calculate_fee(
    level: str,
    fee_window: str = "early", # early | standard
    registration_year: int = 2026,
    is_first_time: bool = True
) -> Dict[str, Any]:
    """
    Deterministic Pricing Logic:
    - 2025: Enrollment Fee = $350 (if first time); Early = $940; Standard = $1250
    - 2026+: Enrollment Fee = $0; Early = $1090; Standard = $1390
    """
    enrollment_fee = 0.0
    if registration_year <= 2025 and is_first_time:
        enrollment_fee = 350.0

    if registration_year <= 2025:
        exam_fee = 940.0 if fee_window == "early" else 1250.0
    else:
        exam_fee = 1090.0 if fee_window == "early" else 1390.0

    total_amount = enrollment_fee + exam_fee
    
    return {
        "enrollment_fee": enrollment_fee,
        "exam_fee": exam_fee,
        "total_amount": total_amount,
        "currency": "USD",
        "fee_window": fee_window,
        "registration_year": registration_year
    }

def process_payment(
    candidate_id: int,
    level: str,
    payment_method: str,
    fee_window: str = "early",
    registration_year: int = 2026,
    is_first_time: bool = True,
    db_path: Optional[str] = None
) -> Dict[str, Any]:
    fee_info = calculate_fee(level, fee_window, registration_year, is_first_time)
    receipt_id = f"REC-{uuid.uuid4().hex[:8].upper()}"
    enrolled_at = datetime.now(timezone.utc).isoformat()
    
    conn = get_connection(db_path)
    cursor = conn.cursor()
    
    cursor.execute("""
    INSERT INTO enrollments (candidate_id, level, status, payment_status, payment_amount, payment_currency, payment_method, enrolled_at, receipt_id, fee_window, registration_year)
    VALUES (?, ?, 'confirmed', 'paid', ?, 'USD', ?, ?, ?, ?, ?)
    """, (candidate_id, level, fee_info["total_amount"], payment_method, enrolled_at, receipt_id, fee_window, registration_year))
    
    enrollment_db_id = cursor.lastrowid
    
    # Write audit log
    cursor.execute("""
    INSERT INTO audit_log (timestamp, candidate_id, action_type, entity, entity_id, performed_by, page, extra_json)
    VALUES (?, ?, 'payment_enrollment', 'enrollments', ?, 'system', 'Explore & Enroll', ?)
    """, (enrolled_at, candidate_id, str(enrollment_db_id), f'{{"receipt_id": "{receipt_id}", "amount": {fee_info["total_amount"]}}}'))
    
    conn.commit()
    conn.close()
    
    return {
        "enrollment_id": enrollment_db_id,
        "candidate_id": candidate_id,
        "level": level,
        "status": "confirmed",
        "payment_status": "paid",
        "amount_paid": fee_info["total_amount"],
        "receipt_id": receipt_id,
        "enrolled_at": enrolled_at
    }

def get_candidate_enrollment(candidate_id: int, level: Optional[str] = None, db_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    if level:
        cursor.execute("SELECT * FROM enrollments WHERE candidate_id = ? AND level = ? AND status = 'confirmed' ORDER BY id DESC LIMIT 1", (candidate_id, level))
    else:
        cursor.execute("SELECT * FROM enrollments WHERE candidate_id = ? AND status = 'confirmed' ORDER BY id DESC LIMIT 1", (candidate_id,))
    row = cursor.fetchone()
    conn.close()
    return dict(row) if row else None
