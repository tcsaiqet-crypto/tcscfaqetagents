from datetime import datetime, timezone
from typing import Dict, Any, Optional, List
from services.db import get_connection

def record_reading_progress(
    candidate_id: int,
    level: str,
    reading_id: str,
    reading_title: str,
    topic: str,
    completion_pct: float,
    time_spent_minutes: int,
    db_path: Optional[str] = None
) -> Dict[str, Any]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    now_str = datetime.now(timezone.utc).isoformat()
    
    cursor.execute("""
    SELECT id FROM content_progress WHERE candidate_id = ? AND reading_id = ?
    """, (candidate_id, reading_id))
    existing = cursor.fetchone()
    
    if existing:
        cursor.execute("""
        UPDATE content_progress
        SET completion_pct = ?, time_spent_minutes = time_spent_minutes + ?, last_accessed = ?
        WHERE id = ?
        """, (completion_pct, time_spent_minutes, now_str, existing["id"]))
        row_id = existing["id"]
    else:
        cursor.execute("""
        INSERT INTO content_progress (candidate_id, level, reading_id, reading_title, topic, completion_pct, time_spent_minutes, last_accessed)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (candidate_id, level, reading_id, reading_title, topic, completion_pct, time_spent_minutes, now_str))
        row_id = cursor.lastrowid
        
    conn.commit()
    conn.close()
    
    return {
        "id": row_id,
        "candidate_id": candidate_id,
        "reading_id": reading_id,
        "completion_pct": completion_pct,
        "last_accessed": now_str
    }

def get_candidate_progress_summary(candidate_id: int, db_path: Optional[str] = None) -> Dict[str, Any]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("""
    SELECT AVG(completion_pct) as avg_pct,
           SUM(time_spent_minutes) as total_mins,
           COUNT(*) as total_count,
           SUM(CASE WHEN completion_pct >= 100 THEN 1 ELSE 0 END) as done_count
    FROM content_progress WHERE candidate_id = ?
    """, (candidate_id,))
    row = cursor.fetchone()
    conn.close()
    
    avg_pct = row["avg_pct"] if row and row["avg_pct"] is not None else 0.0
    total_mins = row["total_mins"] if row and row["total_mins"] is not None else 0
    total_count = row["total_count"] if row and row["total_count"] is not None else 0
    done_count = row["done_count"] if row and row["done_count"] is not None else 0
    
    rounded_pct = round(avg_pct, 1)
    return {
        "candidate_id": candidate_id,
        "average_completion_pct": rounded_pct,
        "overall_progress_pct": rounded_pct,
        "total_study_minutes": total_mins,
        "total_time_spent_minutes": total_mins,
        "completed_readings": done_count,
        "total_readings": total_count
    }
