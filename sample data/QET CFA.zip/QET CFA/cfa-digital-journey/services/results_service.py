from datetime import datetime, timezone
import json
import uuid
from typing import Dict, Any, Optional
from services.db import get_connection

def publish_exam_result(
    candidate_id: int,
    level: str,
    score_pct: float,
    topic_breakdown: Dict[str, Dict[str, Any]],
    db_path: Optional[str] = None
) -> Dict[str, Any]:
    """
    Deterministic Results Processing Engine:
    - Pass/Fail rule: score_pct >= 70.0 -> 'pass', else 'fail'.
    - Categorizes topic performance bands ('Above MPS', 'At MPS', 'Below MPS').
    """
    conn = get_connection(db_path)
    cursor = conn.cursor()
    
    pass_fail = "pass" if score_pct >= 70.0 else "fail"
    score_relative = "Above MPS" if score_pct >= 75.0 else ("At MPS" if score_pct >= 70.0 else "Below MPS")
    
    topic_bands = {}
    for topic, stats in topic_breakdown.items():
        pct = stats.get("score_pct", 0.0)
        if pct >= 75.0:
            band = "Above MPS"
        elif pct >= 65.0:
            band = "At MPS"
        else:
            band = "Below MPS"
        topic_bands[topic] = band
        
    result_id = f"RES-{uuid.uuid4().hex[:8].upper()}"
    released_at = datetime.now(timezone.utc).isoformat()
    
    cursor.execute("""
    INSERT INTO results (candidate_id, level, result_id, released_at, pass_fail, topic_bands, score_relative_to_mps)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (candidate_id, level, result_id, released_at, pass_fail, json.dumps(topic_bands), score_relative))
    
    res_db_id = cursor.lastrowid
    
    # Audit log
    cursor.execute("""
    INSERT INTO audit_log (timestamp, candidate_id, action_type, entity, entity_id, performed_by, page, extra_json)
    VALUES (?, ?, 'publish_result', 'results', ?, 'system', 'My Credentials', ?)
    """, (released_at, candidate_id, str(res_db_id), f'{{"pass_fail": "{pass_fail}", "score_pct": {score_pct}}}'))
    
    conn.commit()
    conn.close()
    
    return {
        "id": res_db_id,
        "result_id": result_id,
        "candidate_id": candidate_id,
        "level": level,
        "pass_fail": pass_fail,
        "score_relative": score_relative,
        "topic_bands": topic_bands,
        "released_at": released_at
    }

def get_candidate_results(candidate_id: int, db_path: Optional[str] = None) -> Optional[Dict[str, Any]]:
    conn = get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM results WHERE candidate_id = ? ORDER BY id DESC LIMIT 1", (candidate_id,))
    row = cursor.fetchone()
    conn.close()
    if not row:
        return None
    d = dict(row)
    d["topic_bands"] = json.loads(d["topic_bands"]) if d.get("topic_bands") else {}
    return d
