import pytest
from agents.crew_config import AgentManager

def test_agent_context_routing_verification():
    mgr = AgentManager()
    
    # 1. Test Study Room — AI Tutor context -> expected "tutor"
    r1 = mgr.route_request("Study Room — AI Tutor", "Explain GIPS standards")
    assert r1 == "tutor"
    
    # 2. Test Explore & Enroll — Schedule / Reschedule Exam context -> expected "support"
    r2 = mgr.route_request("Explore & Enroll — Schedule / Reschedule Exam", "How do I reschedule my exam slot?")
    assert r2 == "support"
    
    # 3. Test Study Room — My Study Plan context -> expected "planner"
    r3 = mgr.route_request("Study Room — My Study Plan", "How many hours should I study per week?")
    assert r3 == "planner"
    
    # Verify process_query returns valid context payload for 3 distinct pages strictly
    profile = {"id": 1, "level_interest": "I"}
    
    q1 = mgr.process_query("What are the ethics standards?", "Study Room — AI Tutor", profile)
    assert q1["agent_used"] == "tutor"
    
    q2 = mgr.process_query("What is the rescheduling fee?", "Explore & Enroll — Schedule / Reschedule Exam", profile)
    assert q2["agent_used"] == "support"
    
    q3 = mgr.process_query("Generate my weekly study plan schedule", "Study Room — My Study Plan", profile)
    assert q3["agent_used"] == "planner"
