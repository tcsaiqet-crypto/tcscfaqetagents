import pytest
from services.db import init_db
from services.profile_service import register_candidate
from services.study_plan_service import get_study_plan, update_study_plan_order
from services.lms_service import record_reading_progress, get_candidate_progress_summary
from services.mock_exam_service import evaluate_mock_exam
from vector_store.build_indexes import build_all_indexes
from tools.faiss_retriever import FAISSIndexRetriever, REFUSAL_PHRASE

@pytest.fixture
def test_db(tmp_path):
    db_file = str(tmp_path / "test_cfa_p3.db")
    init_db(db_file)
    return db_file

def test_study_plan_generation_and_conflict_resolution(test_db):
    cand = register_candidate("Learner", "learner@example.com", "pass123", db_path=test_db)
    plan = get_study_plan(cand["id"], "I", db_path=test_db)
    assert len(plan) == 10
    
    # Drag-and-drop / chat reorder test
    reordered_ids = [plan[1]["id"], plan[0]["id"]] + [p["id"] for p in plan[2:]]
    updated_plan = update_study_plan_order(cand["id"], "I", reordered_ids, modified_by="drag", db_path=test_db)
    assert updated_plan[0]["id"] == plan[1]["id"]
    assert updated_plan[0]["modified_by"] == "drag"

def test_lms_reading_progress(test_db):
    cand = register_candidate("LMS Student", "lms@example.com", "pass123", db_path=test_db)
    record_reading_progress(cand["id"], "I", "R01", "Code of Ethics", "Ethics", 100.0, 45, db_path=test_db)
    summary = get_candidate_progress_summary(cand["id"], db_path=test_db)
    assert summary["average_completion_pct"] == 100.0
    assert summary["total_study_minutes"] == 45

def test_mock_exam_scoring_and_weak_areas(test_db):
    cand = register_candidate("Examinee", "examinee@example.com", "pass123", db_path=test_db)
    
    # Seed questions
    from services.db import get_connection
    conn = get_connection(test_db)
    cursor = conn.cursor()
    cursor.execute("""
    INSERT INTO questions (question_id, level, topic, question_text, option_a, option_b, option_c, correct_option)
    VALUES ('Q1', 'I', 'Ethics', 'Ethics Q1', 'A', 'B', 'C', 'A')
    """)
    cursor.execute("""
    INSERT INTO questions (question_id, level, topic, question_text, option_a, option_b, option_c, correct_option)
    VALUES ('Q2', 'I', 'Quant', 'Quant Q2', 'A', 'B', 'C', 'B')
    """)
    conn.commit()
    conn.close()
    
    answers = {"Q1": "A", "Q2": "A"} # Q1 correct, Q2 wrong
    res = evaluate_mock_exam(cand["id"], "MOCK-1", "I", answers, db_path=test_db)
    assert res["score_pct"] == 50.0
    assert "Quant" in res["weak_areas"]

def test_faiss_builder_and_grounded_retrieval():
    indexes = build_all_indexes()
    assert "curriculum_l1" in indexes
    
    retriever = FAISSIndexRetriever()
    # Test valid query
    res = retriever.retrieve("ethics", agent_role="tutor", domain="curriculum_l1")
    assert len(res["chunks"]) > 0
    
    # Test unpermitted query refusal
    unauth = retriever.retrieve("fee", agent_role="tutor", domain="policies_fees")
    assert unauth["text"] == REFUSAL_PHRASE
