import pytest
from services.db import init_db
from services.profile_service import register_candidate
from services.notifications_service import (
    send_notification,
    get_candidate_inbox,
    update_notification_preferences,
    get_notification_preferences
)
from services.support_service import create_support_ticket, get_candidate_tickets

@pytest.fixture
def test_db(tmp_path):
    db_file = str(tmp_path / "test_cfa_p6.db")
    init_db(db_file)
    return db_file

def test_notification_preferences_and_queueing(test_db):
    cand = register_candidate("Notified User", "notified@example.com", "pass123", db_path=test_db)
    
    # In-app enabled by default
    n1 = send_notification(cand["id"], "Reminder", "7 days until exam", db_path=test_db)
    assert n1 is not None
    assert n1["title"] == "Reminder"
    
    inbox = get_candidate_inbox(cand["id"], db_path=test_db)
    assert len(inbox) == 1
    
    # Disable inapp
    update_notification_preferences(cand["id"], inapp=False, db_path=test_db)
    n2 = send_notification(cand["id"], "Blocked", "Should not send", db_path=test_db)
    assert n2 is None

def test_support_ticket_creation_and_escalation(test_db):
    cand = register_candidate("Help Seeker", "help@example.com", "pass123", db_path=test_db)
    t = create_support_ticket(cand["id"], "Payment Discrepancy", "Card charged twice", "high", db_path=test_db)
    assert t["ticket_id"] is not None
    assert t["status"] == "open"
    
    tickets = get_candidate_tickets(cand["id"], db_path=test_db)
    assert len(tickets) == 1
    assert tickets[0]["subject"] == "Payment Discrepancy"
