from agents.crew_config import AgentManager
from tools.faiss_retriever import REFUSAL_PHRASE


class DummyRetriever:
    def __init__(self):
        self.last_call = None

    def retrieve(self, query, agent_role="tutor", domain="curriculum_l1", top_k=4):
        self.last_call = {
            "query": query,
            "agent_role": agent_role,
            "domain": domain,
            "top_k": top_k,
        }
        return {
            "chunks": [
                "Chunk one about CFA policy.",
                "Chunk two with additional details.",
                "Chunk three with examples.",
            ],
            "sources": ["doc_a", "doc_b", "doc_c"],
            "text": "Chunk one about CFA policy.\n---\nChunk two with additional details.\n---\nChunk three with examples.",
        }


def test_profile_query_uses_deterministic_catalog():
    mgr = AgentManager()
    res = mgr.process_query(
        "what are the different profiles available right now",
        "Dashboard — Overview",
        {"id": 1, "level_interest": "I"},
    )
    assert res["domain_queried"] == "profile_catalog"
    assert "Available profiles in this app right now" in res["response"]


def test_response_options_override_route_and_depth():
    mgr = AgentManager()
    dummy = DummyRetriever()
    mgr.retriever = dummy

    res = mgr.process_query(
        "explain ethics",
        "Study Room — AI Tutor",
        {"id": 1, "level_interest": "I"},
        response_options={
            "agent_override": "support",
            "domain_override": "faq_support",
            "context_depth": 7,
            "preset": "concise",
        },
    )

    assert dummy.last_call["agent_role"] == "support"
    assert dummy.last_call["domain"] == "faq_support"
    assert dummy.last_call["top_k"] == 7
    assert res["preset_used"] == "concise"


def test_custom_instruction_table_format_applies():
    mgr = AgentManager()
    dummy = DummyRetriever()
    mgr.retriever = dummy

    res = mgr.process_query(
        "tell me policy",
        "Help & Support — FAQ",
        {"id": 1, "level_interest": "I"},
        response_options={
            "preset": "balanced",
            "custom_instruction": "answer in table format",
        },
    )

    assert "| # | Key Point |" in res["response"]


def test_refusal_passes_through_when_no_chunks():
    class EmptyRetriever:
        def retrieve(self, *args, **kwargs):
            return {"chunks": [], "sources": [], "text": REFUSAL_PHRASE}

    mgr = AgentManager()
    mgr.retriever = EmptyRetriever()

    res = mgr.process_query("unknown question", "Help & Support — FAQ", {"id": 1, "level_interest": "I"})
    assert res["response"] == REFUSAL_PHRASE
    assert res["sources"] == []
