import os
import pytest
from services.db import init_db
from services.profile_service import (
    register_candidate,
    get_candidate_by_id,
    update_profile,
    calculate_profile_completeness
)
from services.kyc_service import verify_identity, get_kyc_history

@pytest.fixture
def test_db(tmp_path):
    db_file = str(tmp_path / "test_cfa.db")
    init_db(db_file)
    return db_file

def test_candidate_registration(test_db):
    candidate = register_candidate("John Smith", "john@example.com", "SecretPass123", db_path=test_db)
    assert candidate["name"] == "John Smith"
    assert candidate["email"] == "john@example.com"
    assert candidate["candidate_id"].startswith("CFA-")
    assert candidate["kyc_status"] == "pending"

def test_duplicate_registration_fails(test_db):
    register_candidate("John Smith", "john@example.com", "SecretPass123", db_path=test_db)
    with pytest.raises(ValueError):
        register_candidate("John Smith", "john@example.com", "SecretPass123", db_path=test_db)

def test_profile_update_and_completeness(test_db):
    cand = register_candidate("Sarah Chen", "sarah@example.com", "Pass123", db_path=test_db)
    cand_id = cand["id"]
    
    updated = update_profile(
        candidate_db_id=cand_id,
        education="Bachelor of Finance",
        institution="University of Chicago",
        graduation_year=2024,
        work_exp_hours=2000,
        employment_status="Employed",
        level_interest="I",
        target_exam_date="2026-02-15",
        study_hours_week=15,
        knowledge_level="Intermediate",
        db_path=test_db
    )
    assert updated["education"] == "Bachelor of Finance"
    score = calculate_profile_completeness(updated)
    assert score == 100

def test_kyc_auto_approval(test_db):
    cand = register_candidate("Alex Turner", "alex@example.com", "Pass123", db_path=test_db)
    res = verify_identity(
        candidate_db_id=cand["id"],
        id_type="Passport",
        doc_number="P12345678",
        expiry_date_str="2030-12-31",
        liveness_score=92.5,
        db_path=test_db
    )
    assert res["status"] == "VERIFIED"
    
    # Check candidate table updated
    c_updated = get_candidate_by_id(cand["id"], test_db)
    assert c_updated["kyc_status"] == "VERIFIED"

def test_kyc_manual_review_routing(test_db):
    cand = register_candidate("Maria Garcia", "maria@example.com", "Pass123", db_path=test_db)
    res = verify_identity(
        candidate_db_id=cand["id"],
        id_type="Passport",
        doc_number="P98765432",
        expiry_date_str="2030-12-31",
        liveness_score=65.0, # low score
        db_path=test_db
    )
    assert res["status"] == "REQUIRES_MANUAL_REVIEW"
    assert "below 80% threshold" in res["failure_reason"]
    
    c_updated = get_candidate_by_id(cand["id"], test_db)
    assert c_updated["kyc_status"] == "REQUIRES_MANUAL_REVIEW"
