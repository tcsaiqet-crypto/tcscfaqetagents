import pytest
from services.db import init_db
from services.profile_service import register_candidate
from services.results_service import publish_exam_result, get_candidate_results
from services.credential_service import issue_certificate, verify_credential, is_charterholder

@pytest.fixture
def test_db(tmp_path):
    db_file = str(tmp_path / "test_cfa_p5.db")
    init_db(db_file)
    return db_file

def test_result_publishing_and_score_reporting(test_db):
    cand = register_candidate("Result Candidate", "result@example.com", "pass123", db_path=test_db)
    breakdown = {
        "Ethics": {"score_pct": 80.0},
        "Quant": {"score_pct": 60.0}
    }
    res = publish_exam_result(cand["id"], "I", 75.0, breakdown, db_path=test_db)
    assert res["pass_fail"] == "pass"
    assert res["score_relative"] == "Above MPS"
    assert res["topic_bands"]["Ethics"] == "Above MPS"
    assert res["topic_bands"]["Quant"] == "Below MPS"

def test_certificate_issuance_and_public_verification(test_db):
    cand = register_candidate("Certified User", "cert@example.com", "pass123", db_path=test_db)
    cert = issue_certificate(cand["id"], "I", db_path=test_db)
    assert cert["verification_code"].startswith("VERIFY-")
    assert "linkedin.com" in cert["linkedin_url"]
    
    # Verify lookup
    v_res = verify_credential(cert["verification_code"], db_path=test_db)
    assert v_res["valid"] is True
    assert v_res["candidate_name"] == "Certified User"
    assert v_res["verified_count"] == 1

def test_charterholder_transition_check(test_db):
    cand = register_candidate("Future Charterholder", "charter@example.com", "pass123", db_path=test_db)
    assert is_charterholder(cand["id"], db_path=test_db) is False
    
    # Pass Level I, II, III
    breakdown = {"General": {"score_pct": 80.0}}
    publish_exam_result(cand["id"], "I", 80.0, breakdown, db_path=test_db)
    publish_exam_result(cand["id"], "II", 80.0, breakdown, db_path=test_db)
    publish_exam_result(cand["id"], "III", 80.0, breakdown, db_path=test_db)
    
    assert is_charterholder(cand["id"], db_path=test_db) is True
