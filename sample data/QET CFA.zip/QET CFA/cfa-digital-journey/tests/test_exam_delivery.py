import pytest
from services.db import init_db
from services.profile_service import register_candidate
from services.kyc_service import verify_identity
from services.scheduling_service import book_exam_slot
from services.exam_delivery_service import (
    launch_exam_session,
    log_proctoring_event,
    submit_exam_responses
)

@pytest.fixture
def test_db(tmp_path):
    db_file = str(tmp_path / "test_cfa_p4.db")
    init_db(db_file)
    return db_file

def test_launch_gate_unverified_blocked(test_db):
    cand = register_candidate("Unverified Candidate", "unverified@example.com", "pass123", db_path=test_db)
    with pytest.raises(ValueError, match="Identity re-verification failed"):
        launch_exam_session(cand["id"], "I", db_path=test_db)

def test_launch_gate_verified_successful(test_db):
    cand = register_candidate("Verified Candidate", "verified@example.com", "pass123", db_path=test_db)
    verify_identity(cand["id"], "Passport", "P111222", "2030-01-01", 90.0, db_path=test_db)
    book_exam_slot(cand["id"], "I", "2026-05-20", "09:00 AM", "center", "Center A", db_path=test_db)
    
    session = launch_exam_session(cand["id"], "I", db_path=test_db)
    assert session["status"] == "in_progress"
    assert session["session_id"].startswith("SESS-")

def test_proctoring_anomaly_logging(test_db):
    cand = register_candidate("Proctored Candidate", "proctored@example.com", "pass123", db_path=test_db)
    verify_identity(cand["id"], "Passport", "P333444", "2030-01-01", 95.0, db_path=test_db)
    book_exam_slot(cand["id"], "I", "2026-05-20", "09:00 AM", "center", "Center A", db_path=test_db)
    
    session = launch_exam_session(cand["id"], "I", db_path=test_db)
    
    # Log 6-second face missing event -> should trigger flag
    res = log_proctoring_event(session["session_id"], "face_missing", 6.5, "Candidate looked away", db_path=test_db)
    assert res["events_count"] == 1
    assert res["flags_count"] == 1
    assert res["latest_flagged"] is True

def test_response_encryption_and_submission(test_db):
    cand = register_candidate("Submitter", "submitter@example.com", "pass123", db_path=test_db)
    verify_identity(cand["id"], "Passport", "P555666", "2030-01-01", 90.0, db_path=test_db)
    book_exam_slot(cand["id"], "I", "2026-05-20", "09:00 AM", "center", "Center A", db_path=test_db)
    
    session = launch_exam_session(cand["id"], "I", db_path=test_db)
    
    sub = submit_exam_responses(session["session_id"], {"Q1": "A", "Q2": "B"}, db_path=test_db)
    assert sub["status"] == "submitted"
    assert sub["responses_encrypted"] is True
