import pytest
from services.db import init_db
from services.profile_service import register_candidate, update_profile
from services.eligibility_service import check_eligibility
from services.payment_service import calculate_fee, process_payment
from services.scheduling_service import book_exam_slot, reschedule_exam_slot

@pytest.fixture
def test_db(tmp_path):
    db_file = str(tmp_path / "test_cfa_p2.db")
    init_db(db_file)
    return db_file

def test_eligibility_evaluation(test_db):
    cand = register_candidate("Eligible User", "eligible@example.com", "pass123", db_path=test_db)
    cand_updated = update_profile(cand["id"], "Bachelor of Science", "MIT", 2022, 4500, "Employed", "I", "2026-02-15", 15, "Beginner", db_path=test_db)
    
    cand_ineligible = register_candidate("Ineligible User", "ineligible@example.com", "pass123", db_path=test_db)
    
    res1 = check_eligibility(cand_updated, "I", db_path=test_db)
    assert res1["eligible"] is True
    
    res2 = check_eligibility(cand_ineligible, "I", db_path=test_db)
    assert res2["eligible"] is False

def test_fee_calculations():
    # 2025 First-time early
    fee2025 = calculate_fee("I", "early", 2025, is_first_time=True)
    assert fee2025["enrollment_fee"] == 350.0
    assert fee2025["exam_fee"] == 940.0
    assert fee2025["total_amount"] == 1290.0

    # 2026 First-time early (enrollment fee $0)
    fee2026 = calculate_fee("I", "early", 2026, is_first_time=True)
    assert fee2026["enrollment_fee"] == 0.0
    assert fee2026["exam_fee"] == 1090.0
    assert fee2026["total_amount"] == 1090.0

def test_payment_processing(test_db):
    cand = register_candidate("Payer", "payer@example.com", "pass123", db_path=test_db)
    payment = process_payment(cand["id"], "I", "Credit Card", "early", 2026, True, db_path=test_db)
    assert payment["status"] == "confirmed"
    assert payment["payment_status"] == "paid"
    assert payment["receipt_id"].startswith("REC-")

def test_exam_slot_booking_and_reschedule(test_db):
    cand = register_candidate("Scheduler", "scheduler@example.com", "pass123", db_path=test_db)
    slot = book_exam_slot(cand["id"], "I", "2026-05-20", "09:00 AM", "center", "Prometric NYC Center", db_path=test_db)
    assert slot["booking_status"] == "confirmed"
    assert slot["confirmation_code"].startswith("CONF-")
    
    # Reschedule
    rescheduled = reschedule_exam_slot(slot["slot_id"], "2026-05-22", "10:00 AM", db_path=test_db)
    assert rescheduled["status"] == "confirmed"
    assert rescheduled["reschedule_fee"] == 250.0
