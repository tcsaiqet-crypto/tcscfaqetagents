import os
import sqlite3
import streamlit as st
from services.db import init_db, get_connection
from services.profile_service import (
    get_all_candidates,
    get_candidate_by_id,
    register_candidate,
    update_profile,
    calculate_profile_completeness
)
from services.kyc_service import verify_identity, get_kyc_history
from services.eligibility_service import check_eligibility
from services.payment_service import process_payment, get_candidate_enrollment, calculate_fee
from services.scheduling_service import book_exam_slot, reschedule_exam_slot, get_candidate_slots
from services.study_plan_service import get_study_plan, update_study_plan_order
from services.lms_service import get_candidate_progress_summary, record_reading_progress
from services.mock_exam_service import evaluate_mock_exam, get_candidate_mock_history
from services.exam_delivery_service import launch_exam_session, log_proctoring_event, submit_exam_responses
from services.results_service import get_candidate_results, publish_exam_result
from services.credential_service import is_charterholder, verify_credential, issue_certificate
from services.notifications_service import (
    get_candidate_inbox,
    send_notification,
    get_notification_preferences,
    update_notification_preferences
)
from services.support_service import create_support_ticket, get_candidate_tickets
from agents.crew_config import AgentManager
from components.tags import (
    render_system_badge,
    render_ai_badge,
    render_hybrid_badge,
    render_curriculum_badge,
    render_disclaimer
)

st.set_page_config(page_title="CFA Digital Journey", layout="wide", page_icon="🎓")

# Init DB & Session State
init_db()
if "active_candidate_id" not in st.session_state:
    candidates = get_all_candidates()
    st.session_state["active_candidate_id"] = candidates[0]["id"] if candidates else 1

if "llm_provider" not in st.session_state:
    st.session_state["llm_provider"] = "openai"

if "theme_mode" not in st.session_state:
    st.session_state["theme_mode"] = "light"

if "sidebar_collapsed" not in st.session_state:
    st.session_state["sidebar_collapsed"] = False

if "companion_messages" not in st.session_state:
    st.session_state["companion_messages"] = []

if "response_preset" not in st.session_state:
    st.session_state["response_preset"] = "balanced"

if "custom_instruction_text" not in st.session_state:
    st.session_state["custom_instruction_text"] = ""

if "custom_instruction_enabled" not in st.session_state:
    st.session_state["custom_instruction_enabled"] = False

if "context_depth" not in st.session_state:
    st.session_state["context_depth"] = 4

if "agent_override" not in st.session_state:
    st.session_state["agent_override"] = "auto"

if "domain_override" not in st.session_state:
    st.session_state["domain_override"] = "auto"

if "companion_inline_maximized" not in st.session_state:
    st.session_state["companion_inline_maximized"] = False

# ---------------- DESIGN SYSTEM TOKENS & CONSOLIDATED STYLESHEET ----------------
is_dark = (st.session_state["theme_mode"] == "dark")
tokens = {
    "light": {
        "bg": "#F7F9FC",
        "surface": "#FFFFFF",
        "surface_alt": "#F1F5F9",
        "border": "#E2E8F0",
        "text": "#10233C",
        "text_muted": "#64748B",
        "accent": "#0C7C84",
        "accent_soft": "rgba(12, 124, 132, 0.12)",
        "navy": "#0B192C",
        "card_shadow": "0 1px 3px rgba(16, 35, 60, 0.05)",
    },
    "dark": {
        "bg": "#0D1623",
        "surface": "#142236",
        "surface_alt": "#1E2D45",
        "border": "#2A3D57",
        "text": "#E7EDF5",
        "text_muted": "#94A3B8",
        "accent": "#4EC4C8",
        "accent_soft": "rgba(78, 196, 200, 0.15)",
        "navy": "#0B192C",
        "card_shadow": "0 1px 3px rgba(0, 0, 0, 0.3)",
    }
}
t = tokens["dark" if is_dark else "light"]

st.markdown(
    f"""
    <style>
    :root {{
        --cfa-bg: {t['bg']};
        --cfa-surface: {t['surface']};
        --cfa-surface-alt: {t['surface_alt']};
        --cfa-border: {t['border']};
        --cfa-text: {t['text']};
        --cfa-text-muted: {t['text_muted']};
        --cfa-accent: {t['accent']};
        --cfa-accent-soft: {t['accent_soft']};
        --cfa-navy: {t['navy']};
        --cfa-success: #059669;
        --cfa-warning: #D97706;
        --cfa-danger: #DC2626;
        --cfa-focus-ring: rgba(12, 124, 132, 0.25);

        --cfa-fs-h1: 1.75rem;
        --cfa-fs-h2: 1.3rem;
        --cfa-fs-h3: 1.05rem;
        --cfa-fs-body: 0.95rem;
        --cfa-fs-small: 0.8rem;
        --cfa-fs-caption: 0.72rem;

        --cfa-space-1: 4px;
        --cfa-space-2: 8px;
        --cfa-space-3: 12px;
        --cfa-space-4: 16px;
        --cfa-space-5: 24px;
        --cfa-space-6: 32px;

        --cfa-radius-sm: 8px;
        --cfa-radius-md: 12px;
        --cfa-radius-lg: 16px;
        --cfa-shadow-sm: {t['card_shadow']};
        --cfa-shadow-md: 0 4px 12px rgba(0, 0, 0, 0.08);
        --cfa-shadow-lg: 0 8px 24px rgba(0, 0, 0, 0.12);
    }}

    .stApp {{
        background-color: var(--cfa-bg) !important;
    }}

    section[data-testid="stSidebar"] {{
        width: 260px !important;
        min-width: 260px !important;
        max-width: 260px !important;
        background-color: #0B192C !important;
        border-right: 1px solid #1E293B !important;
    }}

    h1, h2, h3, h4, h5, h6, p, label, span, div {{
        color: var(--cfa-text);
    }}

    .cfa-sidebar-brand {{
        font-size: 0.95rem;
        font-weight: 800;
        color: #FFFFFF !important;
        letter-spacing: -0.01em;
        padding-top: 4px;
    }}
    .cfa-sidebar-profile {{
        background: #142843 !important;
        border-radius: 10px;
        padding: 10px;
        margin-bottom: 12px;
    }}
    .cfa-sidebar-profile-name {{
        font-weight: 700;
        font-size: 0.9rem;
        color: #FFFFFF !important;
    }}
    .cfa-sidebar-profile-meta {{
        font-size: 0.78rem;
        color: #94A3B8 !important;
    }}

    .cfa-nav-group-label {{
        font-size: 0.7rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        color: #00D2FF !important;
        margin-top: 16px;
        margin-bottom: 6px;
    }}

    .cfa-nav-item-active {{
        background: rgba(0, 210, 255, 0.10) !important;
        border-left: 3px solid #00D2FF !important;
        border-radius: 8px;
        padding: 8px 10px;
        margin-bottom: 4px;
        color: #FFFFFF !important;
        font-weight: 700;
        font-size: 0.88rem;
    }}

    .cfa-nav-item-active-icon {{
        background: rgba(0, 210, 255, 0.10) !important;
        border-radius: 8px;
        padding: 6px;
        text-align: center;
        margin-bottom: 4px;
        color: #00D2FF !important;
        font-weight: 700;
    }}

    section[data-testid="stSidebar"] button,
    div[data-testid="stSidebar"] div.stButton > button {{
        width: 100%;
        border-radius: 8px !important;
        font-weight: 500 !important;
        font-size: 0.88rem !important;
        padding: 8px 10px !important;
        background-color: transparent !important;
        background: transparent !important;
        color: #C7D3E3 !important;
        border: none !important;
        box-shadow: none !important;
        opacity: 1 !important;
        transition: background 0.15s ease, color 0.15s ease !important;
        text-align: left !important;
        margin-bottom: 2px !important;
    }}
    section[data-testid="stSidebar"] button:hover,
    div[data-testid="stSidebar"] div.stButton > button:hover {{
        background-color: rgba(255, 255, 255, 0.06) !important;
        background: rgba(255, 255, 255, 0.06) !important;
        color: #FFFFFF !important;
        border: none !important;
        box-shadow: none !important;
        opacity: 1 !important;
    }}
    section[data-testid="stSidebar"] button:focus,
    section[data-testid="stSidebar"] button:active,
    div[data-testid="stSidebar"] div.stButton > button:focus {{
        background-color: rgba(255, 255, 255, 0.06) !important;
        background: rgba(255, 255, 255, 0.06) !important;
        color: #FFFFFF !important;
        border: none !important;
        box-shadow: none !important;
        outline: none !important;
        opacity: 1 !important;
    }}
    section[data-testid="stSidebar"] button p,
    section[data-testid="stSidebar"] button span,
    section[data-testid="stSidebar"] button div {{
        color: inherit !important;
        opacity: 1 !important;
    }}

    .cfa-subtab-active {{
        color: var(--cfa-accent) !important;
        font-weight: 700;
        font-size: var(--cfa-fs-body);
        padding: 6px 12px;
        border-bottom: 2px solid var(--cfa-accent) !important;
        text-align: center;
        background: var(--cfa-accent-soft);
        border-radius: var(--cfa-radius-sm) var(--cfa-radius-sm) 0 0;
    }}
    div[data-testid="stHorizontalBlock"] .stButton > button {{
        width: 100%;
        border-radius: var(--cfa-radius-sm) !important;
        font-weight: 500 !important;
        font-size: var(--cfa-fs-body) !important;
        padding: 6px 12px !important;
        background: transparent !important;
        border: none !important;
        color: var(--cfa-text-muted) !important;
        transition: all 0.15s ease !important;
    }}
    div[data-testid="stHorizontalBlock"] .stButton > button:hover {{
        color: var(--cfa-text) !important;
        background: var(--cfa-surface-alt) !important;
    }}

    .cfa-card {{
        background: var(--cfa-surface) !important;
        border: 1px solid var(--cfa-border) !important;
        border-radius: var(--cfa-radius-lg) !important;
        padding: var(--cfa-space-4) !important;
        box-shadow: var(--cfa-shadow-sm) !important;
    }}
    .cfa-rail-card {{
        position: sticky;
        top: 0.75rem;
        background: var(--cfa-surface) !important;
        border: 1px solid var(--cfa-border) !important;
        border-radius: var(--cfa-radius-lg) !important;
        padding: var(--cfa-space-4) !important;
        box-shadow: var(--cfa-shadow-sm) !important;
    }}

    .cfa-provider-badge {{
        background: var(--cfa-accent-soft);
        color: var(--cfa-accent);
        padding: 2px 8px;
        border-radius: 12px;
        font-weight: 700;
        font-size: var(--cfa-fs-caption);
        border: 1px solid var(--cfa-accent);
    }}

    .cfa-breadcrumb {{
        font-size: var(--cfa-fs-small);
        font-weight: 600;
        color: var(--cfa-accent);
        margin-bottom: var(--cfa-space-3);
    }}

    div[data-testid="stMetricValue"] {{
        color: var(--cfa-text) !important;
        font-weight: 800 !important;
    }}
    </style>
    """,
    unsafe_allow_html=True,
)

# Navigation map definition
NAV_MAP = {
    "🏠 Dashboard": ["Overview", "My Progress", "Upcoming Deadlines"],
    "👤 My Profile": ["Register / SSO", "Profile & Education", "Identity Verification (KYC)"],
    "🎓 Explore & Enroll": ["Explore Programs", "Eligibility Check", "Enroll & Pay", "Schedule / Reschedule Exam"],
    "📚 Study Room": ["My Study Plan", "Curriculum Library", "AI Tutor", "Practice & Mock Exams", "Performance Breakdown"],
    "🖥️ Exam Center": ["Exam Day Check-in", "Proctoring Session", "Integrity Log"],
    "🏅 My Credentials": ["Score Report", "Digital Certificate / Badge", "Verify / Share Link"],
    "🔔 Notifications": ["Inbox", "Channel & Frequency Preferences"],
    "💬 Help & Support": ["Chat History", "My Tickets", "FAQ"],
    "🛠️ Admin": [
        "Content / Curriculum Manager",
        "Vector Store Manager",
        "Question Bank Manager",
        "Notification Templates",
        "Data & DB",
        "Audit & Logs",
        "Accessibility Settings",
        "Profile Generator & Upload"
    ]
}

NAV_CATEGORIES = {
    "OVERVIEW & IDENTITY": [
        ("🏠 Dashboard", "🏠", "Dashboard"),
        ("👤 My Profile", "👤", "My Profile"),
    ],
    "LEARNING & EXAMS": [
        ("🎓 Explore & Enroll", "🎓", "Explore & Enroll"),
        ("📚 Study Room", "📚", "Study Room"),
        ("🖥️ Exam Center", "🖥️", "Exam Center"),
    ],
    "CREDENTIALS & SUPPORT": [
        ("🏅 My Credentials", "🏅", "My Credentials"),
        ("🔔 Notifications", "🔔", "Notifications"),
        ("💬 Help & Support", "💬", "Help & Support"),
    ],
    "SYSTEM ADMIN": [
        ("🛠️ Admin", "🛠️", "Admin Portal"),
    ]
}

if "nav_main" not in st.session_state:
    st.session_state["nav_main"] = "🏠 Dashboard"

for main_key, sub_list in NAV_MAP.items():
    sub_key = f"nav_sub_{main_key}"
    if sub_key not in st.session_state:
        st.session_state[sub_key] = sub_list[0]

# ---------------- HEADER WITH TOP-RIGHT PROFILE SWITCHER & THEME TOGGLE ----------------
header_col1, header_col2 = st.columns([3, 1])

with header_col1:
    st.markdown(
        """
        <div style="padding: 2px 0 6px 0;">
            <div style="font-size:var(--cfa-fs-caption); font-weight:800; text-transform:uppercase; letter-spacing:0.1em; color:var(--cfa-accent);">CFA Digital Journey</div>
            <h2 style="margin:2px 0 0 0; color:var(--cfa-text); font-weight:800; font-size:var(--cfa-fs-h1);">Candidate Platform</h2>
        </div>
        """,
        unsafe_allow_html=True
    )

with header_col2:
    candidates = get_all_candidates()
    cand_options = {c["id"]: f"👤 {c['name']} (L{c.get('level_interest') or 'I'})" for c in candidates}
    
    top_c1, top_c2 = st.columns([3, 1])
    with top_c1:
        selected_id = st.selectbox(
            "Active Candidate Profile",
            options=list(cand_options.keys()),
            format_func=lambda x: cand_options[x],
            index=list(cand_options.keys()).index(st.session_state["active_candidate_id"]) if st.session_state["active_candidate_id"] in cand_options else 0,
            key="top_profile_switcher",
            label_visibility="collapsed"
        )
        if selected_id != st.session_state["active_candidate_id"]:
            st.session_state["active_candidate_id"] = selected_id
            st.rerun()

    with top_c2:
        theme_icon = "☀️" if st.session_state["theme_mode"] == "dark" else "🌙"
        if st.button(theme_icon, key="simple_top_theme_btn", help="Switch Light / Dark Theme"):
            st.session_state["theme_mode"] = "light" if st.session_state["theme_mode"] == "dark" else "dark"
            st.rerun()

current_cand = get_candidate_by_id(st.session_state["active_candidate_id"])

# ---------------- NARROW DARK NAVY BLUE SIDEBAR ----------------
with st.sidebar:
    is_collapsed = st.session_state["sidebar_collapsed"]
    toggle_glyph = "«" if not is_collapsed else "»"

    sb_col1, sb_col2 = st.columns([3, 1])
    with sb_col1:
        st.markdown('<div class="cfa-sidebar-brand">CFA Journey</div>', unsafe_allow_html=True)
    with sb_col2:
        if st.button(toggle_glyph, key="navy_sidebar_toggle", help="Toggle sidebar expand/collapse"):
            st.session_state["sidebar_collapsed"] = not st.session_state["sidebar_collapsed"]
            st.rerun()
        
    st.markdown("<hr style='margin:8px 0; border-color:#1E293B;'>", unsafe_allow_html=True)
    
    selected_main = st.session_state["nav_main"]

    if is_collapsed:
        # COLLAPSED ICON-ONLY RAIL
        for cat_title, items in NAV_CATEGORIES.items():
            for full_key, icon, short_label in items:
                is_active = (selected_main == full_key)
                if is_active:
                    st.markdown(f'<div class="cfa-nav-item-active-icon" title="{short_label}">{icon}</div>', unsafe_allow_html=True)
                else:
                    if st.button(icon, key=f"nav_ic_{full_key}", help=short_label):
                        st.session_state["nav_main"] = full_key
                        st.rerun()
    else:
        # UNCOLLAPSED FULL DETAIL RAIL WITH CATEGORIES
        st.markdown(
            f"""
            <div class="cfa-sidebar-profile">
                <div class="cfa-sidebar-profile-name">{current_cand['name']}</div>
                <div class="cfa-sidebar-profile-meta">Level {current_cand.get('level_interest') or 'I'} candidate</div>
            </div>
            """,
            unsafe_allow_html=True
        )
        
        for cat_title, items in NAV_CATEGORIES.items():
            st.markdown(f'<div class="cfa-nav-group-label">{cat_title}</div>', unsafe_allow_html=True)
            for full_key, icon, short_label in items:
                is_active = (selected_main == full_key)
                if is_active:
                    st.markdown(f'<div class="cfa-nav-item-active">{icon}&nbsp;&nbsp;{short_label}</div>', unsafe_allow_html=True)
                else:
                    label_text = f"{icon}  {short_label}"
                    if st.button(label_text, key=f"nav_full_{full_key}"):
                        st.session_state["nav_main"] = full_key
                        st.rerun()

selected_main = st.session_state["nav_main"]
sub_options = NAV_MAP[selected_main]
sub_key = f"nav_sub_{selected_main}"

# ---------------- SUBTAB NAVIGATION (FLAT ACTIVE / PLAIN BUTTON INACTIVE) ----------------
sub_cols = st.columns(len(sub_options))
for idx, sub_name in enumerate(sub_options):
    with sub_cols[idx]:
        is_sub_active = (st.session_state[sub_key] == sub_name)
        if is_sub_active:
            st.markdown(f'<div class="cfa-subtab-active">{sub_name}</div>', unsafe_allow_html=True)
        else:
            if st.button(sub_name, key=f"sub_tab_btn_{selected_main}_{sub_name}"):
                st.session_state[sub_key] = sub_name
                st.rerun()

selected_sub = st.session_state[sub_key]

# Active Context Calculation
clean_main = selected_main.split(" ", 1)[1] if " " in selected_main else selected_main
active_context = f"{clean_main} — {selected_sub}"
st.session_state["active_context"] = active_context

st.markdown(f'<div class="cfa-breadcrumb">📍 {clean_main} / {selected_sub}</div>', unsafe_allow_html=True)

# ---------------- 2-PANEL MAIN LAYOUT ----------------
if st.session_state["companion_inline_maximized"]:
    col_main, col_rail = st.columns([1, 3])
else:
    col_main, col_rail = st.columns([3, 1])

with col_main:
    st.markdown('<div class="cfa-card">', unsafe_allow_html=True)
    # ==================== 1. DASHBOARD ====================
    if selected_main == "🏠 Dashboard":
        st.header(f"Dashboard — {selected_sub}")
        
        if selected_sub == "Overview":
            render_system_badge("System Verified ✓")
            charterholder = is_charterholder(current_cand["id"])
            if charterholder:
                st.success("🏆 CFA Charterholder Status Confirmed!")
                st.info("Member View: All 3 exam levels completed. Continuing Professional Development (CPD) hub active.")
            
            k1, k2, k3 = st.columns(3)
            with k1:
                st.metric("KYC Identity Status", current_cand["kyc_status"].upper())
            with k2:
                comp = calculate_profile_completeness(current_cand)
                st.metric("Profile Completeness", f"{comp}%")
            with k3:
                lms_sum = get_candidate_progress_summary(current_cand["id"])
                avg_pct = lms_sum.get("overall_progress_pct", lms_sum.get("average_completion_pct", 0.0))
                st.metric("LMS Study Progress", f"{avg_pct}%")

            st.markdown("### Quick Navigation & System Announcements")
            st.write(f"Welcome back, **{current_cand['name']}**! Target Exam Window: `{current_cand.get('target_exam_date') or '2026-02-15'}`")

        elif selected_sub == "My Progress":
            render_system_badge("System Verified ✓")
            st.subheader("Detailed Learning & Exam Readiness Progress")
            lms_sum = get_candidate_progress_summary(current_cand["id"])
            avg_pct = lms_sum.get("overall_progress_pct", lms_sum.get("average_completion_pct", 0.0))
            done_cnt = lms_sum.get("completed_readings", 0)
            tot_cnt = lms_sum.get("total_readings", 0)
            tot_mins = lms_sum.get("total_time_spent_minutes", lms_sum.get("total_study_minutes", 0))
            
            st.progress(min(1.0, max(0.0, avg_pct / 100.0)))
            st.write(f"Readings Completed: **{done_cnt} / {tot_cnt}**")
            st.write(f"Total Time Spent: **{tot_mins} mins**")

        elif selected_sub == "Upcoming Deadlines":
            render_system_badge("System Verified ✓")
            st.subheader("Critical Milestones & Deadlines")
            st.info("🗓 Early Registration Deadline for Feb 2026: 10 Dec 2025")
            st.info("🗓 Standard Registration Deadline: 20 Jan 2026")
            st.info("🗓 Exam Rescheduling Window Closes: 05 Feb 2026")

    # ==================== 2. MY PROFILE ====================
    elif selected_main == "👤 My Profile":
        st.header(f"My Profile — {selected_sub}")
        
        if selected_sub == "Register / SSO":
            render_system_badge("System Verified ✓")
            st.subheader("Register New Candidate Profile")
            with st.form("reg_form"):
                r_name = st.text_input("Full Name", value="Alex Taylor")
                r_email = st.text_input("Email", value="alex.taylor@example.com")
                r_edu = st.selectbox("Education Level", ["Bachelor's Degree", "Final Year Student", "Work Experience Only"])
                r_lvl = st.selectbox("CFA Level Interest", ["I", "II", "III"])
                r_hours = st.number_input("Weekly Study Hours Available", 5, 40, 15)
                r_sub = st.form_submit_button("Register Candidate")
                if r_sub:
                    try:
                        c_id = register_candidate(r_name, r_email, "pass123", education=r_edu, level_interest=r_lvl, study_hours_week=r_hours)
                        st.success(f"Candidate created with ID: `{c_id}`!")
                        st.session_state["active_candidate_id"] = c_id
                        st.rerun()
                    except Exception as e:
                        st.error(str(e))

        elif selected_sub == "Profile & Education":
            render_system_badge("System Verified ✓")
            st.subheader("Edit Profile & Educational Qualifications")
            e_edu = st.text_input("Education Background", value=current_cand.get("education") or "")
            e_hours = st.number_input("Work Exp Hours", 0, 10000, current_cand.get("work_exp_hours") or 0)
            e_months = st.number_input("Work Exp Months", 0, 120, current_cand.get("work_exp_months") or 0)
            e_target = st.text_input("Target Exam Date (YYYY-MM-DD)", value=current_cand.get("target_exam_date") or "2026-02-15")
            if st.button("Save Profile Changes"):
                update_profile(current_cand["id"], education=e_edu, work_exp_hours=e_hours, work_exp_months=e_months, target_exam_date=e_target)
                st.success("Profile updated successfully!")
                st.rerun()

        elif selected_sub == "Identity Verification (KYC)":
            render_hybrid_badge("AI + System ◈")
            st.subheader("Automated Digital KYC Verification")
            st.write(f"Current KYC Status: **{current_cand['kyc_status'].upper()}**")
            
            st.markdown("#### Submit Verification Payload")
            doc_type = st.selectbox("ID Document Type", ["Passport", "National Driver's License"])
            liveness = st.slider("Simulated Biometric Liveness Match Score (%)", 50, 100, 85)
            
            if st.button("Submit KYC for Verification"):
                res = verify_identity(current_cand["id"], doc_type, liveness_score=float(liveness))
                if res["status"] == "verified":
                    st.success(f"KYC Approved automatically! Status: {res['status']}")
                else:
                    st.warning(f"KYC Routed for Manual Review. Reason: {res['reason']}")
                st.rerun()

    # ==================== 3. EXPLORE & ENROLL ====================
    elif selected_main == "🎓 Explore & Enroll":
        st.header(f"Explore & Enroll — {selected_sub}")
        
        if selected_sub == "Explore Programs":
            render_system_badge("System Verified ✓")
            st.subheader("CFA Program Level Overview & Prerequisites")
            st.write("• **Level I**: Focuses on foundational knowledge, ethical & professional standards, and investment tools.")
            st.write("• **Level II**: Focuses on asset valuation and application of investment tools.")
            st.write("• **Level III**: Focuses on portfolio management and wealth planning.")

        elif selected_sub == "Eligibility Check":
            render_system_badge("System Verified ✓")
            st.subheader("Deterministic Eligibility Evaluator")
            lvl = st.selectbox("Check Eligibility For Level", ["I", "II", "III"])
            el_res = check_eligibility(current_cand, lvl)
            if el_res["eligible"]:
                st.success(f"Eligible for Level {lvl}! Reason: {el_res['reason']}")
            else:
                st.error(f"Not Eligible for Level {lvl}. Reason: {el_res['reason']}")

        elif selected_sub == "Enroll & Pay":
            render_system_badge("System Verified ✓")
            st.subheader("Program Enrollment & Secure Payment")
            enr = get_candidate_enrollment(current_cand["id"])
            if enr and enr["payment_status"] == "paid":
                st.success(f"Enrolled in Level {enr['level']} | Payment Status: PAID | Receipt: `{enr['receipt_id']}`")
            else:
                target_lvl = current_cand.get("level_interest") or "I"
                fee_info = calculate_fee(target_lvl, "early", 2026)
                st.write(f"Total Amount Payable (USD): **${fee_info['total_amount']}**")
                pm = st.selectbox("Payment Method", ["Credit Card", "Netbanking", "Wire Transfer"])
                if st.button("Process Payment"):
                    p_res = process_payment(current_cand["id"], target_lvl, pm, "early", 2026)
                    st.success(f"Payment successful! Receipt ID: `{p_res['receipt_id']}`")
                    st.rerun()

        elif selected_sub == "Schedule / Reschedule Exam":
            render_system_badge("System Verified ✓")
            st.subheader("CBT Exam Appointment Booking")
            slots = get_candidate_slots(current_cand["id"])
            if slots:
                st.info(f"Booked Slot: {slots[0]['slot_date']} at {slots[0]['center_name']} (Status: {slots[0]['booking_status']})")
                st.markdown("#### Reschedule Exam Slot (USD 250 Fee)")
                new_date = st.text_input("New Date (YYYY-MM-DD)", value="2026-02-18")
                if st.button("Confirm Reschedule"):
                    r_res = reschedule_exam_slot(slots[0]["id"], new_date, "10:00 AM")
                    st.success(f"Rescheduled! Fee charged: ${r_res['reschedule_fee']}")
                    st.rerun()
            else:
                st.write("No slot currently booked.")
                b_date = st.text_input("Select Date (YYYY-MM-DD)", value="2026-02-15")
                b_time = st.selectbox("Time Slot", ["09:00 AM", "01:30 PM"])
                b_center = st.selectbox("Center Type", ["center", "remote"])
                if st.button("Book Exam Slot"):
                    bk = book_exam_slot(current_cand["id"], current_cand.get("level_interest") or "I", b_date, b_time, b_center, "New York Test Center")
                    st.success(f"Booked! Confirmation Code: `{bk['confirmation_code']}`")
                    st.rerun()

    # ==================== 4. STUDY ROOM ====================
    elif selected_main == "📚 Study Room":
        st.header(f"Study Room — {selected_sub}")
        
        if selected_sub == "My Study Plan":
            render_ai_badge("AI Suggested ✦")
            st.subheader("Personalized Study Plan Generator")
            plan_rows = get_study_plan(current_cand["id"])
            if plan_rows:
                st.dataframe(plan_rows)
            else:
                st.info("No study plan rows created yet.")

        elif selected_sub == "Curriculum Library":
            render_curriculum_badge("Curriculum ✓")
            st.subheader("Digital LMS Content & Reading Tracker")
            conn = get_connection()
            c = conn.cursor()
            c.execute("SELECT reading_id, reading_title, topic, completion_pct, time_spent_minutes FROM content_progress WHERE candidate_id = ?", (current_cand["id"],))
            prog_rows = c.fetchall()
            conn.close()
            if prog_rows:
                st.dataframe([dict(r) for r in prog_rows])
            
            st.markdown("#### Record Reading Progress")
            r_id = st.text_input("Reading ID", value="R-ETH-01")
            r_title = st.text_input("Reading Title", value="Ethics & Professional Standards")
            r_topic = st.text_input("Topic", value="Ethical and Professional Standards")
            r_pct = st.slider("Completion %", 0, 100, 100)
            r_time = st.number_input("Time Spent (mins)", 5, 300, 45)
            if st.button("Save LMS Progress"):
                record_reading_progress(current_cand["id"], r_id, r_title, r_topic, float(r_pct), int(r_time))
                st.success("LMS progress saved!")
                st.rerun()

        elif selected_sub == "AI Tutor":
            render_ai_badge("AI Suggested ✦")
            st.subheader("CFA AI Curriculum Tutor")
            t_query = st.text_input("Ask Curriculum Tutor Question:", value="What are the 7 Standards of Professional Conduct?")
            if st.button("Ask Tutor"):
                mgr = AgentManager()
                with st.spinner("Consulting official curriculum RAG index..."):
                    res = mgr.process_query(t_query, "Study Room — AI Tutor", current_cand, st.session_state["llm_provider"])
                st.markdown(res["response"])
                if res["sources"]:
                    with st.expander("▶ View Sources"):
                        for s in res["sources"]:
                            st.caption(f"Source: {s}")

        elif selected_sub == "Practice & Mock Exams":
            render_system_badge("System Verified ✓")
            st.subheader("Practice Tests & Full-Length Mocks")
            st.write("Sample Quick Quiz (2 Questions):")
            ans1 = st.radio("Q1: What is the primary purpose of the GIPS standards?", ["A) To establish global ethical performance reporting", "B) To calculate tax liabilities", "C) To regulate stock exchanges"], index=0)
            ans2 = st.radio("Q2: In time value of money, as interest rate increases, future value of an annuity...", ["A) Decreases", "B) Increases", "C) Remains unchanged"], index=1)
            
            if st.button("Submit Mock Exam"):
                a_map = {"Q1": "A" if "A)" in ans1 else "B", "Q2": "B" if "B)" in ans2 else "A"}
                m_res = evaluate_mock_exam(current_cand["id"], "MOCK-001", current_cand.get("level_interest") or "I", a_map)
                st.success(f"Score: {m_res['score_pct']}% | Weak Areas Identified: {m_res['weak_areas']}")

        elif selected_sub == "Performance Breakdown":
            render_system_badge("System Verified ✓")
            st.subheader("Topic Performance & Weak Area Analytics")
            m_hist = get_candidate_mock_history(current_cand["id"])
            if m_hist:
                st.dataframe(m_hist)
            else:
                st.info("No mock exam attempts logged yet.")

    # ==================== 5. EXAM CENTER ====================
    elif selected_main == "🖥️ Exam Center":
        st.header(f"Exam Center — {selected_sub}")
        
        if selected_sub == "Exam Day Check-in":
            render_system_badge("System Verified ✓")
            st.subheader("Identity Re-verification & Slot Check")
            st.write(f"Candidate: **{current_cand['name']}** (`{current_cand['candidate_id']}`)")
            st.write(f"KYC Verification Status: **{current_cand['kyc_status'].upper()}**")

        elif selected_sub == "Proctoring Session":
            render_hybrid_badge("AI + System ◈")
            st.subheader("Live CBT Exam Environment Launcher")
            if st.button("Launch CBT Exam Session"):
                try:
                    sess = launch_exam_session(current_cand["id"], current_cand.get("level_interest") or "I")
                    st.success(f"Exam Session Active! Session ID: `{sess['session_id']}`")
                    log_proctoring_event(sess["session_id"], "face_missing", 6.0, "Face missing 6s")
                    submit_exam_responses(sess["session_id"], {"Q1": "A", "Q2": "B"})
                    st.info("Exam submitted. Response payload encrypted.")
                except Exception as e:
                    st.error(str(e))

        elif selected_sub == "Integrity Log":
            render_system_badge("System Verified ✓")
            st.subheader("Proctoring Integrity Event Logs")
            conn = get_connection()
            c = conn.cursor()
            c.execute("SELECT session_id, status, proctoring_log, integrity_flags FROM exam_sessions WHERE candidate_id = ?", (current_cand["id"],))
            s_rows = c.fetchall()
            conn.close()
            if s_rows:
                st.dataframe([dict(r) for r in s_rows])
            else:
                st.info("No exam proctoring sessions recorded.")

    # ==================== 6. MY CREDENTIALS ====================
    elif selected_main == "🏅 My Credentials":
        st.header(f"My Credentials — {selected_sub}")
        
        if selected_sub == "Score Report":
            render_system_badge("System Verified ✓")
            st.subheader("Official Exam Score Report")
            res = get_candidate_results(current_cand["id"])
            if res:
                st.write(f"Exam Result: **{res['pass_fail'].upper()}** | Relative to MPS: **{res['score_relative']}**")
                st.json(res["topic_bands"])
            else:
                st.info("No exam result record published for this candidate.")

        elif selected_sub == "Digital Certificate / Badge":
            render_system_badge("System Verified ✓")
            st.subheader("Tamper-Proof Digital Certificate & Badge")
            if st.button("Issue Digital Certificate"):
                cert = issue_certificate(current_cand["id"], current_cand.get("level_interest") or "I")
                st.success(f"Issued Certificate ID: `{cert['certificate_id']}`")
                st.write(f"Verification Code: `{cert['verification_code']}`")
                st.write(f"LinkedIn Share URL: [Add to LinkedIn Profile]({cert['linkedin_url']})")

        elif selected_sub == "Verify / Share Link":
            render_system_badge("System Verified ✓")
            st.subheader("Public Third-Party Credential Verification")
            v_code = st.text_input("Enter Verification Code to Lookup", value="VERIFY-MOCKCODE123")
            if st.button("Verify Credential"):
                v_res = verify_credential(v_code)
                if v_res["valid"]:
                    st.success(f"VERIFIED! Candidate: {v_res['candidate_name']} | Level: {v_res['level']} | Lookups: {v_res['verified_count']}")
                else:
                    st.error(v_res["reason"])

    # ==================== 7. NOTIFICATIONS ====================
    elif selected_main == "🔔 Notifications":
        st.header(f"Notifications — {selected_sub}")
        
        if selected_sub == "Inbox":
            render_system_badge("System Verified ✓")
            st.subheader("Candidate In-App Notifications")
            inbox = get_candidate_inbox(current_cand["id"])
            if inbox:
                for item in inbox:
                    st.write(f"🔔 **{item['title']}** (`{item['sent_at'][:10]}`): {item['body']}")
            else:
                st.info("Inbox is currently empty.")

        elif selected_sub == "Channel & Frequency Preferences":
            render_system_badge("System Verified ✓")
            st.subheader("Communication Channel Preferences")
            prefs = get_notification_preferences(current_cand["id"])
            inapp_c = st.checkbox("In-App Notifications", value=bool(prefs.get("inapp_enabled", 1)))
            email_c = st.checkbox("Email Alerts", value=bool(prefs.get("email_enabled", 0)))
            sms_c = st.checkbox("SMS Reminders", value=bool(prefs.get("sms_enabled", 0)))
            push_c = st.checkbox("Mobile Push Notifications", value=bool(prefs.get("push_enabled", 0)))
            
            if st.button("Save Preferences"):
                update_notification_preferences(current_cand["id"], inapp_c, email_c, sms_c, push_c)
                st.success("Preferences updated!")

    # ==================== 8. HELP & SUPPORT ====================
    elif selected_main == "💬 Help & Support":
        st.header(f"Help & Support — {selected_sub}")
        
        if selected_sub == "Chat History":
            render_system_badge("System Verified ✓")
            st.subheader("Recent Helpdesk Chat Transcripts")
            st.caption("All interactions logged to audit_log table.")

        elif selected_sub == "My Tickets":
            render_system_badge("System Verified ✓")
            st.subheader("Support Tickets & Escalation")
            tickets = get_candidate_tickets(current_cand["id"])
            if tickets:
                st.dataframe(tickets)
                
            st.markdown("---")
            st.markdown("**Create New Ticket**")
            t_subj = st.text_input("Ticket Subject", value="Invoice Receipt Inquiry")
            t_desc = st.text_area("Issue Description", value="Need receipt PDF copy for corporate reimbursement.")
            t_prio = st.selectbox("Priority", ["low", "normal", "high"], index=1)
            if st.button("Submit Support Ticket"):
                create_support_ticket(current_cand["id"], t_subj, t_desc, t_prio)
                st.success("Support ticket created and routed to team.")
                st.rerun()

        elif selected_sub == "FAQ":
            render_curriculum_badge("Curriculum ✓")
            st.subheader("Frequently Asked Questions")
            st.write("**Q: What calculators are allowed?**")
            st.write("A: Only Texas Instruments BA II Plus and HP 12C models.")
            st.write("**Q: How do I reschedule my exam?**")
            st.write("A: Rescheduling within window is allowed for a USD 250 fee in Explore & Enroll.")

    # ==================== 9. ADMIN ====================
    elif selected_main == "🛠️ Admin":
        st.header(f"Admin — {selected_sub}")
        
        if selected_sub == "Content / Curriculum Manager":
            render_system_badge("System Verified ✓")
            st.subheader("Curriculum Content Manager")
            st.caption("Manage raw markdown knowledge files.")

        elif selected_sub == "Vector Store Manager":
            render_system_badge("System Verified ✓")
            st.subheader("FAISS Index Manager")
            st.write("Frozen Embedding Model: `text-embedding-3-small`")
            if st.button("Trigger Index Rebuild"):
                from vector_store.build_indexes import build_all_indexes
                res = build_all_indexes()
                st.success(f"Indexes rebuilt: {res}")

        elif selected_sub == "Question Bank Manager":
            render_system_badge("System Verified ✓")
            st.subheader("MCQ Question Bank Repository")
            conn = get_connection()
            c = conn.cursor()
            c.execute("SELECT question_id, level, topic, question_text, correct_option FROM questions")
            q_rows = c.fetchall()
            conn.close()
            st.dataframe([dict(r) for r in q_rows])

        elif selected_sub == "Notification Templates":
            render_system_badge("System Verified ✓")
            st.subheader("System Notification Templates")
            st.write("Template 1: Exam Date Reminder (T-7 Days)")
            st.write("Template 2: Results Released Notification")

        elif selected_sub == "Data & DB":
            render_system_badge("System Verified ✓")
            st.subheader("Database Maintenance & Seeding")
            if st.button("Re-seed Database & Reset State"):
                from scripts.seed_db import seed_database
                seed_database()
                st.success("Database successfully reset and re-seeded!")
                st.rerun()

        elif selected_sub == "Audit & Logs":
            render_system_badge("System Verified ✓")
            st.subheader("System Audit Log Table")
            conn = get_connection()
            c = conn.cursor()
            c.execute("SELECT log_id, timestamp, candidate_id, action_type, entity, page, performed_by FROM audit_log ORDER BY log_id DESC LIMIT 20")
            logs = c.fetchall()
            conn.close()
            st.dataframe([dict(r) for r in logs])

        elif selected_sub == "Accessibility Settings":
            render_system_badge("System Verified ✓")
            st.subheader("WCAG 2.1 AA Accessibility Controls")
            admin_theme = st.radio("Display Theme", ["light", "dark"], format_func=lambda x: "☀️ Light Mode" if x == "light" else "🌙 Dark Mode", index=0 if st.session_state["theme_mode"] == "light" else 1, key="admin_theme_radio")
            if admin_theme != st.session_state["theme_mode"]:
                st.session_state["theme_mode"] = admin_theme
                st.rerun()
            st.checkbox("High Contrast Mode")
            st.checkbox("Large Text Mode")

        elif selected_sub == "Profile Generator & Upload":
            render_system_badge("System Verified ✓")
            st.subheader("Batch Synthetic Candidate Generator")
            g_cnt = st.number_input("Number of Profiles to Generate", 1, 10, 3)
            if st.button("Generate Test Profiles"):
                for i in range(g_cnt):
                    register_candidate(f"Synthetic User {i+1}", f"synth{i+1}@example.com", "pass123")
                st.success(f"Generated {g_cnt} synthetic test profiles!")
                st.rerun()

# ==================== RIGHT RAIL DEDICATED AI COMPANION PANEL ====================
with col_rail:
    st.markdown('<div class="cfa-rail-card">', unsafe_allow_html=True)
    
    # Header row with title + small provider pill badge
    curr_prov = st.session_state["llm_provider"].upper()
    st.markdown(
        f"""
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:4px;">
            <h3 style="margin:0; font-size:var(--cfa-fs-h3); color:var(--cfa-text); font-weight:800;">🤖 AI Companion</h3>
            <span class="cfa-provider-badge">{curr_prov}</span>
        </div>
        <div style="font-size:var(--cfa-fs-caption); color:var(--cfa-text-muted); margin-bottom:10px;">Context: <b>{active_context}</b></div>
        """,
        unsafe_allow_html=True
    )

    action_col1, action_col2 = st.columns(2)
    with action_col1:
        toggle_label = "Compress Panel" if st.session_state["companion_inline_maximized"] else "Maximize Panel"
        if st.button(toggle_label, key="companion_toggle_max", use_container_width=True):
            st.session_state["companion_inline_maximized"] = not st.session_state["companion_inline_maximized"]
            st.rerun()
    with action_col2:
        if st.button("Open Full Chat", key="companion_open_full", use_container_width=True):
            st.switch_page("pages/companion.py")
    
    # Provider Selector (Two small toggle buttons instead of radio)
    p_col1, p_col2 = st.columns(2)
    with p_col1:
        if st.session_state["llm_provider"] == "openai":
            st.markdown('<div class="cfa-subtab-active" style="padding:4px 6px; font-size:var(--cfa-fs-caption);">OpenAI</div>', unsafe_allow_html=True)
        else:
            if st.button("OpenAI", key="btn_prov_openai"):
                st.session_state["llm_provider"] = "openai"
                st.rerun()
    with p_col2:
        if st.session_state["llm_provider"] == "gemini":
            st.markdown('<div class="cfa-subtab-active" style="padding:4px 6px; font-size:var(--cfa-fs-caption);">Gemini</div>', unsafe_allow_html=True)
        else:
            if st.button("Gemini", key="btn_prov_gemini"):
                st.session_state["llm_provider"] = "gemini"
                st.rerun()

    st.caption("Recommended default: Balanced. You can also set custom instructions.")

    preset_options = ["auto", "balanced", "concise", "detailed", "examples"]
    current_preset = st.session_state["response_preset"]
    if current_preset not in preset_options:
        current_preset = "balanced"
    st.session_state["response_preset"] = st.selectbox(
        "Response style",
        preset_options,
        index=preset_options.index(current_preset),
        key="companion_response_preset",
        help="Auto chooses style by question type."
    )

    st.session_state["custom_instruction_enabled"] = st.toggle(
        "Apply Custom Instruction",
        value=st.session_state["custom_instruction_enabled"],
        help="Turn on to apply your custom rule while asking questions."
    )

    st.session_state["custom_instruction_text"] = st.text_input(
        "Custom instruction",
        value=st.session_state["custom_instruction_text"],
        placeholder="Example: answer in table + 3 examples + medium length",
        max_chars=200,
        key="companion_custom_instruction"
    )

    with st.expander("Advanced options", expanded=False):
        st.session_state["agent_override"] = st.selectbox(
            "Agent override",
            ["auto", "tutor", "planner", "support"],
            index=["auto", "tutor", "planner", "support"].index(st.session_state["agent_override"] if st.session_state["agent_override"] in ["auto", "tutor", "planner", "support"] else "auto"),
            key="companion_agent_override"
        )
        st.session_state["domain_override"] = st.selectbox(
            "Domain override",
            ["auto", "curriculum_l1", "curriculum_l2", "curriculum_l3", "faq_support", "policies_fees", "glossary", "question_bank"],
            index=["auto", "curriculum_l1", "curriculum_l2", "curriculum_l3", "faq_support", "policies_fees", "glossary", "question_bank"].index(st.session_state["domain_override"] if st.session_state["domain_override"] in ["auto", "curriculum_l1", "curriculum_l2", "curriculum_l3", "faq_support", "policies_fees", "glossary", "question_bank"] else "auto"),
            key="companion_domain_override"
        )
        st.session_state["context_depth"] = st.slider(
            "Context depth (chunks)",
            1,
            10,
            int(st.session_state["context_depth"]),
            key="companion_context_depth"
        )

    st.markdown("<hr style='margin:10px 0; border-color:var(--cfa-border);'>", unsafe_allow_html=True)

    # Scrollable chat history area (st.container(height=420))
    container_height = 680 if st.session_state["companion_inline_maximized"] else 420
    with st.container(height=container_height):
        if not st.session_state["companion_messages"]:
            st.caption("Ask questions about curriculum, study plan, or platform guidelines.")
        for msg in st.session_state["companion_messages"]:
            with st.chat_message(msg["role"]):
                st.markdown(msg["content"])
                if msg["role"] == "assistant" and msg.get("meta"):
                    m = msg["meta"]
                    st.caption(
                        f"preset={m.get('preset','-')} | agent={m.get('agent','-')} | domain={m.get('domain','-')} | k={m.get('context_depth','-')}"
                    )
                if msg.get("sources"):
                    with st.expander("▶ View Sources"):
                        for s in msg["sources"]:
                            st.caption(f"Source: {s}")

    # Form Composer for Enter-to-submit
    with st.form("ai_companion_composer_form", clear_on_submit=True):
        user_text = st.text_input("Ask AI Companion", placeholder="Ask a question...", label_visibility="collapsed", key="companion_chat_input_val")
        submitted = st.form_submit_button("Send 🚀", use_container_width=True)
        if submitted and user_text.strip():
            st.session_state["companion_messages"].append({
                "role": "user",
                "content": user_text.strip()
            })

            custom_instruction = st.session_state["custom_instruction_text"].strip() if st.session_state["custom_instruction_enabled"] else ""
            response_options = {
                "preset": st.session_state["response_preset"],
                "custom_instruction": custom_instruction,
                "context_depth": st.session_state["context_depth"],
                "agent_override": None if st.session_state["agent_override"] == "auto" else st.session_state["agent_override"],
                "domain_override": None if st.session_state["domain_override"] == "auto" else st.session_state["domain_override"],
            }

            mgr = AgentManager()
            resp = mgr.process_query(
                user_text.strip(),
                active_context,
                current_cand,
                st.session_state["llm_provider"],
                response_options=response_options,
            )
            st.session_state["companion_messages"].append({
                "role": "assistant",
                "content": resp["response"],
                "sources": resp.get("sources", []),
                "meta": {
                    "preset": resp.get("preset_used", st.session_state["response_preset"]),
                    "agent": resp.get("agent_used"),
                    "domain": resp.get("domain_queried"),
                    "context_depth": st.session_state["context_depth"],
                }
            })

            if len(st.session_state["companion_messages"]) > 100:
                st.session_state["companion_messages"] = st.session_state["companion_messages"][-100:]
            st.rerun()

    render_disclaimer()
    st.markdown('</div>', unsafe_allow_html=True)

with col_main:
    st.markdown('</div>', unsafe_allow_html=True)
