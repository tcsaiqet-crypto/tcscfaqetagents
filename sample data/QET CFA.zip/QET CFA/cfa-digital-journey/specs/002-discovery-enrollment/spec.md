# Feature Specification: 002-discovery-enrollment

**Feature Title**: Program & Exam Discovery, Enrollment, Fee Payment & Slot Scheduling  
**Business Requirements**: BR-03 (Program & Exam Discovery), BR-04 (Enrollment & Fee Payment), BR-09 (Exam Slot Scheduling & Booking)  
**Cross-Cutting Governance**: BR-16 (Accessibility), BR-17 (Privacy & Security), BR-18 (Reliability & Scalability)  
**Target UI Surfaces**: Explore & Enroll (Explore Programs, Eligibility Check, Enroll & Pay, Schedule/Reschedule Exam)

---

## 1. Executive Summary & Purpose

The **Discovery & Enrollment** feature enables prospective and returning candidates to explore CFA levels, evaluate prerequisites, validate eligibility, complete secure online fee payments, and schedule exam slots at testing centers or via remote proctoring.

All eligibility checks, fee pricing math, gateway simulation, receipt issuance, and attempt frequency enforcement are governed by **pure deterministic Python logic**, while AI narration explains eligibility gap analysis without altering business outcomes.

---

## 2. User Scenarios & Acceptance Criteria

### Scenario 1: Program Browsing & Prerequisite Validation (BR-03) `[Static]`
- **Given** a candidate exploring CFA Levels (Level I, Level II, Level III),
- **When** the candidate views program details,
- **Then**:
  1. System renders prerequisites, topic weights, exam formats, and fees `[Static]`.
  2. Sequential level checks verify candidate has passed lower levels before allowing higher level enrollment `[Static]`.

### Scenario 2: Deterministic Eligibility Evaluation & AI Explanation (BR-03) `[Hybrid]`
- **Given** a candidate checking eligibility for Level I,
- **When** the deterministic engine evaluates candidate degree status or work experience (>=4000 hours over >=36 months),
- **Then**:
  1. Eligibility decision (`ELIGIBLE` or `NOT_ELIGIBLE`) is determined strictly by rules `[Static]`.
  2. If not eligible, gap analysis is rendered with hybrid labelling `[Hybrid]`.

### Scenario 3: Secure Fee Payment & Receipt Issuance (BR-04) `[Static]`
- **Given** an eligible candidate enrolling for an exam level,
- **When** the candidate selects payment method (Card, Net-Banking, Mock Wallet) and submits payment,
- **Then**:
  1. System calculates fee basis: 2025 vs 2026 pricing (2026 removes $350 enrollment fee) and Early ($940/$1090) vs Standard ($1250/$1390) window `[Static]`.
  2. Payment is processed via simulated PCI-DSS gateway and instant receipt code is generated `[Static]`.
  3. Enrollment record is created and dashboard reflects confirmed status `[Static]`.

### Scenario 4: Exam Slot Booking & Attempt Limit Enforcement (BR-09) `[Static]`
- **Given** an enrolled candidate scheduling an exam appointment,
- **When** the candidate selects a date, center type (center vs. remote), and location,
- **Then**:
  1. System checks attempt rules: max 2 attempts per year, at least 6 months apart, max 6 lifetime attempts per level `[Static]`.
  2. Rescheduling within window calculates $250 fee `[Static]`.
  3. Confirmation code is generated and calendar event queued `[Static]`.

---

## 3. Success Criteria

- **Metric 1**: 100% of eligibility verdicts are deterministic and reproducible `[Static]`.
- **Metric 2**: 100% of successful payments generate an instant receipt code and update enrollment status in SQLite `[Static]`.
- **Metric 3**: 100% of slot booking requests validate the 6-month retake gap and 6-attempt lifetime limit `[Static]`.
