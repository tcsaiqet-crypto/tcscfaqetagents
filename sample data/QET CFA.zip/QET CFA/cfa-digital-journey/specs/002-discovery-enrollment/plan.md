# Implementation Plan: 002-discovery-enrollment

**Feature**: Program & Exam Discovery, Enrollment, Fee Payment & Slot Scheduling  
**Spec**: [spec.md](file:///c:/Users/AkshatSinha/Documents/avd/QET%20CFA/cfa-digital-journey/specs/002-discovery-enrollment/spec.md)

---

## 1. Technical Architecture & Component Design

### Database Tables (SQLite)
- `enrollments`: Enrollment status, fee window, payment details, receipt ID.
- `exam_slots`: Booked slots, center/remote type, rescheduling history, confirmation codes.

### Service Modules (`services/`)
- `services/eligibility_service.py`: `check_eligibility()`, `validate_level_prerequisites()`.
- `services/payment_service.py`: `calculate_fee()`, `process_payment()`, `get_receipt()`.
- `services/scheduling_service.py`: `get_available_slots()`, `book_exam_slot()`, `reschedule_exam_slot()`.

---

## 2. Verification Plan

### Automated Tests (`tests/test_discovery_enrollment.py`)
- Test eligibility verification for bachelor's degree holder vs under-qualified candidate.
- Test sequential level prerequisite verification (Level II requires passed Level I).
- Test fee calculations for 2025 vs 2026 registration windows.
- Test exam slot booking, 6-month retake gap constraint, and $250 rescheduling fee logic.
