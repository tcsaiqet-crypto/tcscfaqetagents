# Tasks: 002-discovery-enrollment

1. **Eligibility Engine**: Implement `services/eligibility_service.py` for degree, work experience, and level prerequisite checks.
2. **Payment Engine**: Implement `services/payment_service.py` for 2025/2026 fee calculations, mock gateway processing, and receipt generation.
3. **Scheduling Engine**: Implement `services/scheduling_service.py` for slot availability, 6-month retake gap check, rescheduling fee, and booking confirmations.
4. **Automated Verification**: Create `tests/test_discovery_enrollment.py` and run pytest.
