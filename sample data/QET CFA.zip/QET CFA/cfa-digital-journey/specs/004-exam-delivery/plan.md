# Implementation Plan: 004-exam-delivery

**Feature**: Secure Exam Delivery & AI-Assisted Proctoring  
**Spec**: [spec.md](file:///c:/Users/AkshatSinha/Documents/avd/QET%20CFA/cfa-digital-journey/specs/004-exam-delivery/plan.md)

---

## 1. Technical Architecture & Component Design

### Database Tables (SQLite)
- `exam_sessions`: Session ID, status, proctoring_log JSON, integrity_flags JSON, encrypted_responses blob.

### Service Modules (`services/`)
- `services/exam_delivery_service.py`: `launch_exam_session()`, `log_proctoring_event()`, `submit_exam_responses()`.

---

## 2. Verification Plan

### Automated Tests (`tests/test_exam_delivery.py`)
- Test launch gate blocking unverified candidates.
- Test proctoring anomaly signal logging (face missing > 5s).
- Test encrypted response payload creation on submission.
