# Feature Specification: 004-exam-delivery

**Feature Title**: Secure Exam Delivery & AI-Assisted Proctoring  
**Business Requirements**: BR-10 (Secure Exam Delivery & Proctoring)  
**Cross-Cutting Governance**: BR-16 (Accessibility), BR-17 (Privacy & Security), BR-18 (Reliability & Scalability)  
**Target UI Surfaces**: Exam Center (Exam Day Check-in, Proctoring Session, Integrity Log)

---

## 1. Executive Summary & Purpose

The **Exam Delivery** feature manages the secure execution of the CFA exam session. It enforces mandatory pre-exam identity re-verification, runs a deterministic synthetic proctoring event logger (flagging anomalies like face missing > 5s or secondary voice), and persists encrypted response payloads.

All proctoring flags, launch gates, and audit logs are governed by **pure deterministic Python logic**, adhering to Constitution Rule 1.

---

## 2. User Scenarios & Acceptance Criteria

### Scenario 1: Identity Re-verification & Exam Launch Gate (BR-10) `[Static]`
- **Given** a candidate arriving at the Exam Day Check-in,
- **When** the candidate attempts to launch the exam session,
- **Then**:
  1. System checks candidate identity status and confirmed slot `[Static]`.
  2. Exam launches ONLY if identity is re-verified and slot is valid `[Static]`.

### Scenario 2: Deterministic Synthetic Proctoring Anomaly Logging (BR-10) `[Hybrid]`
- **Given** an active exam session in progress,
- **When** synthetic proctoring signals simulate events (e.g. face missing > 5s or secondary audio),
- **Then**:
  1. Integrity violation flags and timestamps are logged to `exam_sessions` table `[Static]`.
  2. Flag explanations are rendered in the Integrity Log with high-stakes expandable source panels expanded by default `[Hybrid]`.

### Scenario 3: Response Payload Encryption & Submission (BR-10) `[Static]`
- **Given** a candidate completing or submitting an exam session,
- **When** responses are finalized,
- **Then**:
  1. Exam responses are encrypted end-to-end (stored as an encrypted payload blob) `[Static]`.
  2. Session status updates to `submitted` and audit log is recorded `[Static]`.

---

## 3. Success Criteria

- **Metric 1**: 100% of unverified candidate exam launch attempts are blocked `[Static]`.
- **Metric 2**: 100% of proctoring anomaly events produce an immutable log in `exam_sessions` `[Static]`.
- **Metric 3**: 100% of submitted exam payloads are encrypted before DB write `[Static]`.
