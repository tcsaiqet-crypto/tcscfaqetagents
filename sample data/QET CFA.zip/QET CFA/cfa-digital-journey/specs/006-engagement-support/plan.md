# Implementation Plan: 006-engagement-support

**Feature**: Omni-Channel Notifications & AI Support Chatbot Helpdesk  
**Spec**: [spec.md](file:///c:/Users/AkshatSinha/Documents/avd/QET%20CFA/cfa-digital-journey/specs/006-engagement-support/plan.md)

---

## 1. Technical Architecture & Component Design

### Database Tables (SQLite)
- `notifications`: Notifications queue and read tracking.
- `notification_preferences`: Channel preference flags per candidate.
- `support_tickets`: Escalated support tickets, page context, status.

### Service Modules (`services/`)
- `services/notifications_service.py`: `send_notification()`, `get_inbox()`, `update_preferences()`.
- `services/support_service.py`: `create_support_ticket()`, `get_candidate_tickets()`.
- `tools/ticket_tool.py`: Support Agent ticket creation tool binding.

---

## 2. Verification Plan

### Automated Tests (`tests/test_engagement_support.py`)
- Test notification preference enforcement (in-app vs email/SMS).
- Test in-app inbox retrieval and read-status updating.
- Test ticket creation, escalation routing, and status tracking.
