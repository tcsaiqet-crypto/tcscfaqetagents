# Feature Specification: 006-engagement-support

**Feature Title**: Omni-Channel Notifications & AI Support Chatbot Helpdesk  
**Business Requirements**: BR-14 (Notifications & Omni-Channel Communication), BR-15 (Support, Helpdesk & Chatbot Assistance)  
**Cross-Cutting Governance**: BR-16 (Accessibility), BR-17 (Privacy & Security), BR-18 (Reliability & Scalability)  
**Target UI Surfaces**: Notifications (Inbox, Channel & Frequency Preferences), Help & Support (Chat History, My Tickets, FAQ), Admin (Notification Templates)

---

## 1. Executive Summary & Purpose

The **Engagement & Support** feature manages candidate communications and helpdesk operations. It delivers in-app milestone reminders, respects candidate channel preferences, provides a grounded CrewAI Support Agent for candidate queries, and automatically escalates complex issues to human support tickets.

All ticket creation, preference enforcement, and notification queueing are governed by **pure deterministic Python logic**, while the Support Agent provides grounded answers from policy/FAQ indexes.

---

## 2. User Scenarios & Acceptance Criteria

### Scenario 1: Omni-Channel Notifications & Preferences (BR-14) `[Static]`
- **Given** an active candidate with notification preferences,
- **When** an automated system trigger occurs (e.g. 7-day exam reminder, result published),
- **Then**:
  1. System checks candidate channel preferences (in-app enabled by default for POC) `[Static]`.
  2. Notification is queued and rendered in candidate Inbox `[Static]`.

### Scenario 2: Grounded Support Chatbot Assistance (BR-15) `[AI-Required]`
- **Given** a candidate asking operational questions (registration deadlines, fees, exam rules) in Help & Support,
- **When** the Support agent queries `policies_fees` and `faq_support` FAISS indexes,
- **Then**:
  1. Grounded response with exact retrieved facts and policy citations is rendered `[AI-Required]`.
  2. If query context is ungrounded or missing, refusal guidance is rendered `[AI-Required]`.

### Scenario 3: Automated Human Support Escalation (BR-15) `[Hybrid]`
- **Given** a candidate requesting human support or reporting a payment/KYC discrepancy,
- **When** the Support agent or candidate triggers ticket creation,
- **Then**:
  1. Ticket is created in `support_tickets` table with page context and candidate ID `[Static]`.
  2. Confirmation code and status (`open`) are displayed in My Tickets subtab `[Static]`.
  3. Escalation notification is logged `[Hybrid]`.

---

## 3. Success Criteria

- **Metric 1**: 100% of candidate notification preference settings are respected before sending reminders `[Static]`.
- **Metric 2**: 100% of escalated support requests create an auditable ticket in `support_tickets` `[Static]`.
- **Metric 3**: 100% of Support Agent responses cite policy sources or output refusal guidance `[AI-Required]`.
