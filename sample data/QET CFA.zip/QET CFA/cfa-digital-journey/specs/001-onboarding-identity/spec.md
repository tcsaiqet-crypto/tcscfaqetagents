# Feature Specification: 001-onboarding-identity

**Feature Title**: Candidate Registration, Guided Onboarding & Digital Identity Verification (KYC)  
**Business Requirements**: BR-01 (Candidate Registration & Digital Onboarding), BR-02 (Identity Verification & KYC)  
**Cross-Cutting Governance**: BR-16 (Accessibility), BR-17 (Privacy & Security), BR-18 (Reliability & Scalability)  
**Target UI Surfaces**: My Profile (Register/SSO, Profile & Education, Identity Verification), Dashboard (Overview), Admin (Audit & Logs)

---

## 1. Executive Summary & Purpose

The **Onboarding & Identity** feature provides prospective candidates with a guided, self-service digital registration process, captures candidate profile and education background, provisions a personalized dashboard within 3 seconds, and executes secure, auditable digital identity verification (KYC).

All business decisions (registration creation, email uniqueness check, liveness threshold evaluation, KYC status transitions, manual review flags) are governed by **pure deterministic Python logic**, adhering to Constitution Principles 1 & 2.

---

## 2. User Scenarios & Acceptance Criteria

### Scenario 1: Self-Registration & SSO Mock (BR-01) `[Static]`
- **Given** a prospective candidate accessing the platform on web or mobile,
- **When** the candidate submits registration (Name, Email, Password) or clicks "Sign-In with Mock SSO",
- **Then**:
  1. Input validation confirms valid email syntax and non-empty password `[Static]`.
  2. Candidate account is created with a unique candidate ID (format `CFA-YYYY-XXXXX`) `[Static]`.
  3. Dashboard provisioning completes in under 3.0 seconds `[Static]`.
  4. Session state persists across rerun `[Static]`.

### Scenario 2: Guided Profile & Educational Entry (BR-01) `[Static]`
- **Given** an authenticated candidate completing onboarding,
- **When** the candidate fills in educational degree, institution, graduation year, employment hours, and target CFA level interest,
- **Then**:
  1. Profile data is saved in encrypted synthetic storage `[Static]`.
  2. Dashboard profile completeness gauge updates `[Static]`.

### Scenario 3: Digital Identity Verification & Automated KYC (BR-02) `[Hybrid]`
- **Given** a registered candidate submitting government ID details and biometric liveness score simulation,
- **When** the deterministic KYC engine processes the submission,
- **Then**:
  1. Expiry date and document structure are validated `[Static]`.
  2. If liveness score >= 80% and document valid, KYC status is set to `VERIFIED` `[Static]`.
  3. Contextual explanation of KYC requirements is rendered with appropriate labelling `[Hybrid]`.
  4. Audit log entry is written to SQLite `[Static]`.

### Scenario 4: Failed / Suspicious KYC Routing to Manual Review (BR-02) `[Static]`
- **Given** a candidate submitting an expired ID or low liveness score (< 80%),
- **When** the KYC engine evaluates the document,
- **Then**:
  1. KYC status is set to `REQUIRES_MANUAL_REVIEW` or `REJECTED` with explicit failure codes `[Static]`.
  2. In-app notification is queued `[Static]`.
  3. Case is logged in Admin Audit Log for reviewer action `[Static]`.

---

## 3. Success Criteria

- **Metric 1**: 100% of registration attempts provision dashboard state in under 3 seconds `[Static]`.
- **Metric 2**: 100% of KYC verification events generate an auditable record in SQLite `[Static]`.
- **Metric 3**: 100% of suspicious submissions (<80% liveness score or expired document) route to `REQUIRES_MANUAL_REVIEW` or `REJECTED` `[Static]`.
