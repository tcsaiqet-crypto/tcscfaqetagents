# Tasks: 001-onboarding-identity

1. **DB Setup**: Create `services/db.py` to initialize SQLite schema (`data/cfa_journey.db`).
2. **Profile Service**: Implement `services/profile_service.py` for registration and profile management.
3. **KYC Rules Engine**: Implement `services/kyc_service.py` for deterministic document and liveness verification.
4. **UI Components**: Create `components/tags.py` for three-tier labelling.
5. **My Profile Page**: Implement `pages/my_profile.py` for Streamlit.
6. **Automated Verification**: Create `tests/test_onboarding_kyc.py` and run pytest.
