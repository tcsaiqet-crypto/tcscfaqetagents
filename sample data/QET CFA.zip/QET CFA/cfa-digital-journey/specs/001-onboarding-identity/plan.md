# Implementation Plan: 001-onboarding-identity

**Feature**: Candidate Registration, Digital Onboarding & Identity Verification (KYC)  
**Spec**: [spec.md](file:///c:/Users/AkshatSinha/Documents/avd/QET%20CFA/cfa-digital-journey/specs/001-onboarding-identity/spec.md)

---

## 1. Technical Architecture & Component Design

### Database Tables (SQLite)
- `candidates`: Candidate profiles, authentication hashes, KYC status.
- `audit_log`: Interaction and status transition logging.

### Service Modules (`services/`)
- `services/db.py`: SQLite connection pool, schema migrations, initialization helpers.
- `services/profile_service.py`: `register_candidate()`, `get_candidate()`, `update_profile()`.
- `services/kyc_service.py`: `verify_identity()` deterministic rules engine.

### Streamlit UI Components
- `pages/my_profile.py`: Multi-subtab interface for Registration/SSO, Profile & Education, and Identity Verification.
- `components/tags.py`: UI Labelling badges (`[System Verified ✓]`, `[AI Suggested ✨]`, etc.).

---

## 2. Verification Plan

### Unit & Integration Tests (`tests/test_onboarding_kyc.py`)
- Test candidate registration and email uniqueness enforcement.
- Test profile update and completeness calculation.
- Test KYC auto-approval for liveness score >= 80% and unexpired ID.
- Test KYC manual review routing for liveness score < 80% or expired ID.
