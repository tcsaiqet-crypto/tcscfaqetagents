# Tasks: 003-learning-ecosystem

1. **Study Plan Engine**: Implement `services/study_plan_service.py` for plan generation, topic reordering, and conflict resolution.
2. **LMS Service**: Implement `services/lms_service.py` for reading progress tracking.
3. **Mock Exam Engine**: Implement `services/mock_exam_service.py` for scoring MCQs and identifying weak areas.
4. **FAISS Builder**: Create `vector_store/build_indexes.py` to index knowledge base raw markdown files.
5. **Retriever & LLM Factory**: Create `tools/faiss_retriever.py` and `agents/llm_factory.py`.
6. **CrewAI Agents**: Create `agents/tutor_agent.py`, `agents/planner_agent.py`, `agents/support_agent.py`, `agents/router_agent.py`.
7. **Automated Verification**: Create `tests/test_learning_ecosystem.py` and run pytest.
