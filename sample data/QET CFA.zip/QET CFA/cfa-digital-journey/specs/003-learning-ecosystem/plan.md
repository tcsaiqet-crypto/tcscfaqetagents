# Implementation Plan: 003-learning-ecosystem

**Feature**: AI Personalized Learning Path, LMS, AI Study Assistant (Tutor), Mock Exams & Progress Analytics  
**Spec**: [spec.md](file:///c:/Users/AkshatSinha/Documents/avd/QET%20CFA/cfa-digital-journey/specs/003-learning-ecosystem/spec.md)

---

## 1. Technical Architecture & Component Design

### Database Tables (SQLite)
- `study_plans`: Topic sequence, planned hours, status, modified_by ('drag'|'chat'|'ai').
- `content_progress`: Reading completion percentages and time-on-content.
- `mock_exams`: Total questions, correct answers, score %, topic breakdown JSON, weak areas JSON.
- `questions`: MCQ bank with topic tags and correct answers.

### Service & Agent Modules
- `services/study_plan_service.py`: Study plan generation, topic reordering, conflict resolution.
- `services/lms_service.py`: Reading completion and progress tracking.
- `services/mock_exam_service.py`: Automated scoring and weak-area identification.
- `vector_store/build_indexes.py`: Builder script for FAISS split indexes (`curriculum_l1`, `curriculum_l2`, `curriculum_l3`, `policies_fees`, `faq_support`, `glossary`, `question_bank`) using `text-embedding-3-small`.
- `tools/faiss_retriever.py`: FAISS retriever wrapper with index permission enforcement.
- `agents/llm_factory.py`: Provider switcher for OpenAI / Gemini.
- `agents/tutor_agent.py` & `agents/planner_agent.py`: CrewAI specialist agents.

---

## 2. Verification Plan

### Automated Tests (`tests/test_learning_ecosystem.py`)
- Test initial study plan generation and topic order modification ("last action wins").
- Test LMS content progress recording.
- Test mock exam automated scoring and weak-area extraction (< 70% threshold).
- Test FAISS split index builder and retriever refusal phrase when context is missing.
