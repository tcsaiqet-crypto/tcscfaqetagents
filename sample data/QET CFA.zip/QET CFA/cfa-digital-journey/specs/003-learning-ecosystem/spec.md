# Feature Specification: 003-learning-ecosystem

**Feature Title**: AI Personalized Learning Path, LMS, AI Study Assistant (Tutor), Mock Exams & Progress Analytics  
**Business Requirements**: BR-05 (AI-Driven Personalized Learning Path), BR-06 (Digital Learning Content & LMS), BR-07 (AI Study Assistant / Tutor), BR-08 (Practice Tests & Mock Exams), BR-13 (Progress Tracking & Analytics Dashboard)  
**Cross-Cutting Governance**: BR-16 (Accessibility), BR-17 (Privacy & Security), BR-18 (Reliability & Scalability)  
**Target UI Surfaces**: Study Room (My Study Plan, Curriculum Library, AI Tutor, Practice & Mock Exams, Performance Breakdown), Dashboard (Overview, Progress)

---

## 1. Executive Summary & Purpose

The **Learning Ecosystem** represents the core preparation hub for CFA candidates. It provides an adaptive study plan mapped to curriculum topics, a structured LMS tracking candidate completion, an AI Study Tutor grounded strictly in FAISS domain indexes, automated mock exam scoring with weak-area detection, and real-time progress analytics.

All scoring, plan row updates, and progress calculations are governed by **deterministic Python logic**, while CrewAI agents (Tutor and Planner) provide grounded explanations, recommendations, and topic reordering narration.

---

## 2. User Scenarios & Acceptance Criteria

### Scenario 1: Tailored Study Plan Generation & Edit Conflict (BR-05) `[Hybrid]`
- **Given** an enrolled candidate accessing "My Study Plan",
- **When** the study plan engine generates a schedule based on target exam date and weekly hours,
- **Then**:
  1. System creates ordered topic study plan rows mapped to the Level curriculum `[Static]`.
  2. Candidate can reorder topics via drag-and-drop or chat edit `[Hybrid]`.
  3. Edit policy applies "last action wins" without popups and refreshes UI immediately `[Static]`.

### Scenario 2: LMS Content Tracking (BR-06) `[Static]`
- **Given** a candidate reading a curriculum topic or viewing reading materials,
- **When** the candidate completes a reading or spends study time,
- **Then**:
  1. Progress percentages and minutes spent are persisted to `content_progress` table `[Static]`.
  2. Topic completion status updates `[Static]`.

### Scenario 3: Grounded AI Tutor & Refusal Handling (BR-07) `[AI-Required]`
- **Given** a candidate asking a curriculum question to the AI Tutor in Study Room,
- **When** the Tutor agent queries the `curriculum_l*` FAISS index,
- **Then**:
  1. If matching chunks exist, response is generated strictly from context and cites reading/LOS `[AI-Required]`.
  2. If Level II/III deep reading is missing or no context found, response outputs standard refusal phrase `[AI-Required]`.
  3. AI Tutor refuses to answer fee/scoring questions `[AI-Required]`.

### Scenario 4: Automated Mock Scoring & Weak-Area Feedback (BR-08) `[Hybrid]`
- **Given** a candidate completing a practice test or mock exam,
- **When** the candidate submits answers,
- **Then**:
  1. System calculates correct count, percentage score, and topic breakdown `[Static]`.
  2. Topics scoring < 70% are identified as weak areas and fed into study plan recommendations `[Static]`.
  3. Explanatory feedback is rendered `[Hybrid]`.

### Scenario 5: Integrated Dashboard & Analytics (BR-13) `[Static]`
- **Given** a candidate viewing the Dashboard or Performance Breakdown,
- **When** analytics render,
- **Then**:
  1. Overall completion %, mock average, and readiness indicators update in real time `[Static]`.

---

## 3. Success Criteria

- **Metric 1**: 100% of study plan edits update the SQLite database and apply "last action wins" `[Static]`.
- **Metric 2**: 100% of AI Tutor responses cite valid sources or output the standard refusal phrase `[AI-Required]`.
- **Metric 3**: 100% of completed mock exams calculate topic-level performance breakdown accurately `[Static]`.
