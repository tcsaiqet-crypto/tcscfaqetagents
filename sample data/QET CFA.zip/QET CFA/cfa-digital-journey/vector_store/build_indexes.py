import os
import json
from datetime import datetime, timezone

RAW_DIR = os.path.join("knowledge_base", "raw")
INDEXES_DIR = os.path.join("vector_store", "faiss_indexes")

DOMAIN_MAP = {
    "curriculum_structure.md": ["curriculum_l1", "curriculum_l2", "curriculum_l3"],
    "fees_registration.md": ["policies_fees"],
    "exam_day_rules.md": ["faq_support"],
    "results_certification.md": ["faq_support"],
    "faq_candidates.md": ["faq_support"],
    "glossary.md": ["glossary"]
}

def split_markdown_into_chunks(filepath: str) -> list:
    if not os.path.exists(filepath):
        return []
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()
        
    sections = content.split("\n## ")
    chunks = []
    fname = os.path.basename(filepath)
    
    for i, sec in enumerate(sections):
        text = sec if i == 0 else f"## {sec}"
        text = text.strip()
        if text:
            # extract first line as title
            lines = text.splitlines()
            title = lines[0].strip("# ") if lines else fname
            chunks.append({
                "chunk_id": f"{fname}_{i}",
                "source": f"{fname} — {title}",
                "content": text
            })
    return chunks

def build_all_indexes():
    os.makedirs(INDEXES_DIR, exist_ok=True)
    summary = {}
    
    for fname, domains in DOMAIN_MAP.items():
        raw_path = os.path.join(RAW_DIR, fname)
        chunks = split_markdown_into_chunks(raw_path)
        
        for dom in domains:
            dom_path = os.path.join(INDEXES_DIR, dom)
            os.makedirs(dom_path, exist_ok=True)
            
            meta_file = os.path.join(dom_path, "index_meta.json")
            existing_chunks = []
            if os.path.exists(meta_file):
                try:
                    with open(meta_file, "r", encoding="utf-8") as f:
                        existing_chunks = json.load(f).get("chunks", [])
                except Exception:
                    pass
                    
            combined = existing_chunks + chunks
            with open(meta_file, "w", encoding="utf-8") as f:
                json.dump({"domain": dom, "chunk_count": len(combined), "chunks": combined}, f, indent=2)
                
            summary[dom] = len(combined)
            
    # Build build_meta.json
    build_meta = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "embedding_model": "text-embedding-3-small",
        "indexes": summary
    }
    with open(os.path.join("vector_store", "build_meta.json"), "w", encoding="utf-8") as f:
        json.dump(build_meta, f, indent=2)
        
    return summary

if __name__ == "__main__":
    res = build_all_indexes()
    print("Build complete:", res)
