import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from services.db import init_db
from services.profile_service import register_candidate, update_profile
from services.kyc_service import verify_identity
from services.payment_service import process_payment
from services.scheduling_service import book_exam_slot
from services.study_plan_service import generate_default_study_plan
from services.results_service import publish_exam_result
from services.credential_service import issue_certificate
from vector_store.build_indexes import build_all_indexes

def seed_database():
    db_path = os.path.join("data", "cfa_journey.db")
    if os.path.exists(db_path):
        try:
            os.remove(db_path)
        except Exception:
            pass
    init_db(db_path)
    
    # 1. Candidate 1: John Smith (Level I, Engineering, Verified)
    c1 = register_candidate("John Smith", "john.smith@example.com", "Password123", db_path=db_path)
    update_profile(c1["id"], "Bachelor of Engineering", "MIT", 2023, 4200, "Employed", "I", "2026-02-15", 12, "Beginner", db_path=db_path)
    verify_identity(c1["id"], "Passport", "P10001", "2030-01-01", 95.0, db_path=db_path)
    process_payment(c1["id"], "I", "Credit Card", "early", 2026, True, db_path=db_path)
    book_exam_slot(c1["id"], "I", "2026-02-15", "09:00 AM", "center", "Prometric NYC Center", db_path=db_path)
    generate_default_study_plan(c1["id"], "I", db_path=db_path)

    # 2. Candidate 2: Sarah Chen (Level II, Finance, Verified)
    c2 = register_candidate("Sarah Chen", "sarah.chen@example.com", "Password123", db_path=db_path)
    update_profile(c2["id"], "Master of Finance", "NYU Stern", 2021, 5000, "Employed", "II", "2026-05-20", 15, "Intermediate", db_path=db_path)
    verify_identity(c2["id"], "Passport", "P10002", "2029-06-30", 91.0, db_path=db_path)
    process_payment(c2["id"], "II", "Credit Card", "early", 2026, False, db_path=db_path)
    book_exam_slot(c2["id"], "II", "2026-05-20", "01:30 PM", "center", "Prometric Chicago Center", db_path=db_path)
    generate_default_study_plan(c2["id"], "II", db_path=db_path)
    publish_exam_result(c2["id"], "I", 82.0, {"Ethics": {"score_pct": 85.0}}, db_path=db_path)

    # 3. Candidate 3: David Lee (Level III, Private Wealth, Verified & Charterholder)
    c3 = register_candidate("David Lee", "david.lee@example.com", "Password123", db_path=db_path)
    update_profile(c3["id"], "Bachelor of Business", "Columbia", 2019, 6000, "Employed", "III", "2025-08-15", 20, "Advanced", db_path=db_path)
    verify_identity(c3["id"], "Passport", "P10003", "2028-11-15", 98.0, db_path=db_path)
    process_payment(c3["id"], "III", "Credit Card", "early", 2025, False, db_path=db_path)
    generate_default_study_plan(c3["id"], "III", db_path=db_path)
    
    publish_exam_result(c3["id"], "I", 85.0, {"Ethics": {"score_pct": 90.0}}, db_path=db_path)
    publish_exam_result(c3["id"], "II", 80.0, {"FSA": {"score_pct": 82.0}}, db_path=db_path)
    publish_exam_result(c3["id"], "III", 78.0, {"Asset Allocation": {"score_pct": 79.0}}, db_path=db_path)
    issue_certificate(c3["id"], "CHARTER", db_path=db_path)

    # Build vector indexes
    build_all_indexes()
    print("Database and vector store successfully seeded.")

if __name__ == "__main__":
    seed_database()
