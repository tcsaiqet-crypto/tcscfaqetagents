<!-- SYNC IMPACT REPORT
Version: 1.1.0
Ratification Date: 2026-08-12
Last Amended Date: 2026-08-12
Modified Principles: Standardized Speckit structures under .specify/ and expanded principles to 16 items.
-->

# CFA Digital Candidate Journey Constitution

## Overview
This document serves as the governing constitution for the CFA Digital Candidate Journey platform. It defines non-negotiable architectural principles, data protection guidelines, AI governance rules, and cross-cutting requirements (BR-16, BR-17, BR-18) that MUST be strictly adhered to across all features and implementation phases.

---

## Non-Negotiable Principles

### Principle 1: Deterministic Business Rules First
- **Rule**: All core business processes—including Candidate Registration & Onboarding (BR-01), Identity Verification & KYC (BR-02), Program Eligibility & Fee Payment (BR-03, BR-04), Exam Slot Scheduling (BR-09), Scoring & Pass/Fail evaluation (BR-11), and Credential/Certificate issuance (BR-12)—MUST be implemented as pure, deterministic Python functions/services.
- **Rationale**: Core candidate status, financial, and compliance decisions must be 100% predictable, testable, and auditable, completely free of non-deterministic LLM behavior.

### Principle 2: AI Companion Narrates, Never Decides
- **Rule**: CrewAI agents (Router, Tutor, Planner, Support) and AI tools MUST ONLY explain, tutor, summarize, or guide candidates based on retrieved facts. Agents MUST NOT execute state mutations or overwrite business rules (e.g., agents cannot approve KYC, mark an exam passed, or modify fee totals).
- **Rationale**: Prevents prompt injection risks and ensures AI serves exclusively as a supportive companion while business integrity is guarded by deterministic code.

### Principle 3: Typed Contracts & Service Layer Encapsulation
- **Rule**: All application logic MUST be exposed through strictly typed Python service interfaces (using Pydantic models or dataclasses). Agents and UI components MUST interact with database engines exclusively through these service APIs in `services/`, never via direct raw SQLite queries.
- **Rationale**: Ensures modular architecture, clean separation of concerns, and seamless future wrapping into FastAPI backend services.

### Principle 4: Full Auditability & Interaction Lineage
- **Rule**: Every AI agent interaction and invocation MUST be logged to the SQLite `audit_log` table. Logs must record: timestamp, candidate_id, page, agent_used, model_used, user_input, context_retrieved (truncated), sources (JSON), final_response (truncated), model_used, provider, latency_ms, and error status.
- **Rationale**: Fulfills enterprise compliance requirements, enables debugging of agent responses, and guarantees complete traceability.

### Principle 5: Reproducibility & Database Rebuilds
- **Rule**: Standardized seed scripts (`scripts/seed_db.py`) and reset scripts (`scripts/reset_db.py`) MUST be provided to reset and recreate SQLite databases and FAISS vector stores reliably. Database reset capability must be exposed via the Admin tab.
- **Rationale**: Protects candidate privacy and guarantees consistent, repeatable developer and testing environments.

### Principle 6: Offline-Capable Execution
- **Rule**: The application must run locally on standard developer workstations with zero external cloud database or hosting dependencies. The only allowed outbound calls are to the configured OpenAI or Google Gemini LLM chat models.
- **Rationale**: Ensures high portability, performance, privacy, and suitability for local and offline demonstrations.

### Principle 7: Synthetic-Only Data Hygiene
- **Rule**: No real PII (Personally Identifiable Information) shall ever be ingested, processed, or committed. All candidate records, test data, documents, and biometric mock inputs MUST be synthetic. Standardized seed scripts MUST be used to populate test profiles.
- **Rationale**: Protects candidate privacy and ensures legal compliance.

### Principle 8: RAG Grounding & Refusal
- **Rule**: RAG retrievers MUST only retrieve top-k chunks from the domain-isolated indexes permitted for the current agent. If no context chunks are returned, the agent must output exactly: 
  "I don't have that information. Please refer to the official CFA Institute website (cfainstitute.org)."
- **Rationale**: Prevents hallucination of curriculum facts, scheduling windows, or fee structures.

### Principle 9: FAISS Split Indexes & Domain Isolation
- **Rule**: FAISS vector stores must be split into isolated index directories by domain: `curriculum_l1/`, `curriculum_l2/`, `curriculum_l3/`, `policies_fees/`, `faq_support/`, `glossary/`, and `question_bank/`. Tutor agent must only query `curriculum_*` indexes, Support agent must only query `faq_support` and `policies_fees`, and Router agent has no index access.
- **Rationale**: Mitigates weak metadata filtering in FAISS and prevents cross-contamination of domain contexts.

### Principle 10: Embedding Freeze Rule
- **Rule**: The embedding model is fixed to OpenAI `text-embedding-3-small` (unless explicitly overridden by user configuration before first index build). Chat models can switch dynamically between OpenAI and Gemini, but the embedding model MUST remain frozen to prevent index corruption.
- **Rationale**: Embeddings from different vector spaces are incompatible and will cause retrieval failures.

### Principle 11: Three-Tier UI Labelling System
- **Rule**: All UI interfaces must apply the three-tier labelling system defined in `uilabelling.txt` to clearly distinguish system facts from AI suggestions:
  - Tier 1: Section Headers (e.g. [SYSTEM] or [AI INSIGHT])
  - Tier 2: Inline tags + tooltips (e.g., `[System Verified ✓]` in green, `[AI Suggested ✨]` in purple, `[AI + System ◈]` in blue, `[Curriculum ✓]` in grey, and `[Not Available]` in grey)
  - Tier 3: Expandable "How was this generated?" source panels containing model, sources, timestamp, and disclaimers.
- **Rationale**: Establishes transparency, user trust, and clear expectations on system vs. AI capabilities.

### Principle 12: BR-16 Accessibility & Inclusion (WCAG 2.1 AA)
- **Rule**: Interface must meet WCAG 2.1 AA accessibility standards. Color must never be the sole indicator of state (always accompany color with text labels and icons). Form inputs and expanders must support keyboard focus. Accommodation requests (e.g. extra time) must be supported.
- **Rationale**: Ensures equitable access for all candidates.

### Principle 13: BR-17 Data Privacy, Consent, & Simulated RBAC
- **Rule**: Synthetic candidate PII must be encrypted at rest (e.g. using Fernet encryption in database files). Candidate consent flags and retention policies must be stored. Admin features must require administrative role checks, although visible to all for POC demonstration simplicity.
- **Rationale**: Aligns system design with GDPR guidelines.

### Principle 14: BR-18 Reliability, Fault Tolerance, & Persistence
- **Rule**: Invocations to LLMs must incorporate a retry loop (minimum 3 attempts) with exponential backoff. Clear error warnings must be displayed to users in case of outage. Session state must persist across Streamlit reruns.
- **Rationale**: Maintains a high SLA simulation and professional candidate experience.

### Principle 15: Mandatory Speckit Workflow
- **Rule**: All feature development must follow the Speckit lifecycle: `/speckit-specify` → `/speckit-clarify` → `/speckit-plan` → `/speckit-tasks` → `/speckit-implement` sequentially. No ad-hoc, freestyle coding of features is permitted.
- **Rationale**: Ensures rigorous documentation quality, traceability, and reviewability.

### Principle 16: Action Item Categorization in Specifications
- **Rule**: Every `spec.md` generated during feature specification MUST explicitly tag each Acceptance Criteria (AC) as either `[Static]` (deterministic rule/system logic), `[Hybrid]` (system decides, AI explains/personalizes), or `[AI-Required]` (pure LLM content generation/RAG response).
- **Rationale**: Standardizes specification clarity and directly drives service layer vs. agent partitioning in the implementation plans.
